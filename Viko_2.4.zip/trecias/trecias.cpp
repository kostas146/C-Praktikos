// trecias.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <cmath>
int main()
{
    long double an = 0;
    long double an1 = 0;
    double e = 0.00001;
   double n = 1;
    
    do
    {
        an = (n + 1) / (sqrt(pow(n + 1,2) + 1)*sqrt(pow(n + 1,2) - 1));
        an1 = ((n + 1) + 1) / (sqrt(pow((n + 1) + 1,2) + 1) * sqrt(pow((n + 1) + 1,2) - 1));
        n++;

    } while (abs(an1 - an) > e);
        std::cout << n << "\n";
        std::cout << an1 << "\n";
}
