﻿// ketvirtas.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

int main()
{


    long long int skaicius;
    int limitas = 60;
    int counter = 0;
    bool funkcija(long long int skaicius);


    std::cout << "palidrominiai: ";
  
    for (skaicius = 0; counter != 60; skaicius++ ) {
        if (funkcija(skaicius) && funkcija(skaicius * skaicius))
        {
            counter++;
            std::cout << skaicius << " ";
        }
    }
    return 0;
}


bool funkcija(long long int sk) {
       long long int n = sk;
      long long  int liekana, atbula = 0;
        while (sk > 0) {

            liekana = sk % 10;
            atbula = atbula * 10 + liekana;
            sk /= 10;
        }
        return (n == atbula);
    }


//4.     Skaičius vadinamas palindromu, jei jis vienodai skaitomas iš abiejų pusių.Parašykite programą, kuri rastų pirmus 60 palindromų, kurių kvadratai taip pat palindromai.


