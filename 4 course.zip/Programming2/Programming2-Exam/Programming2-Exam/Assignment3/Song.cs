﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3
{
    class Song
    {
        public int Ranking;
        public string Title;
        public string Artist;
        public int Year;
    }
}
