﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Program my= new Program();
            my.Start();
        }

        void Start()
        {
            RobotAdapter robot = new RobotAdapter();
            robot.AssignDriver();

            Tank tank = new Tank();
            tank.AssignDriver();

            Console.WriteLine("\n");

            List<IAttacker> attacker = new List<IAttacker>();
            attacker.Add(tank);
            attacker.Add(robot);

         foreach(IAttacker attack in attacker)
            {
                attack.DriveForward();
                attack.UseWeapon();
                Console.WriteLine("\n");
            }

            Console.ReadKey();
        }
    }
}
