﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_3
{
    public class RobotAdapter : IAttacker
    {
        private Robot rob = new Robot();
        public void UseWeapon()
        { rob.BashWithHands(); }
        public void AssignDriver()
        {rob.MoveByPerson();}

        public void DriveForward()
        {rob.WalkForward();}

       
    }
}
