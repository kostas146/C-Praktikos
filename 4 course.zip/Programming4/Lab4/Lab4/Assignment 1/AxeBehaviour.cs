﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_1
{
    public class AxeBehaviour : IWeaponBehaviour
    {
        public void UseWeapon()
        {
             Console.WriteLine("Chopping with an axe.");
        }
    }
}
