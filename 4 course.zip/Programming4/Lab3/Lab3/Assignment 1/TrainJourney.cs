﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_1
{
    public class TrainJourney : ITrainJourney
    {
        private List<TrainStation> stations = new List<TrainStation>();
        private List<ITrainDisplay> Observ = new List<ITrainDisplay>();
        

        TrainStation currentStation;
        int currentStationn;
        bool direction;

        public TrainJourney()
        {
            stations.Add(new TrainStation("Delft", "1", new DateTime(2020,06,05,04,00,00), new DateTime(2020, 08, 16, 00, 00, 00)));
            stations.Add(new TrainStation("Leiden Centraal", "5b", new DateTime(2020, 07, 08, 03, 10, 00), new DateTime(2020, 05, 06, 07, 31, 00)));
            stations.Add(new TrainStation("Schiphol Airport", "1-2", new DateTime(2020, 01, 03, 07, 44, 00), new DateTime(2020, 07, 04, 02, 16, 00)));
            stations.Add(new TrainStation("Den Haag HS", "6", new DateTime(2020, 01, 01, 01, 25, 20), new DateTime(2020, 06, 08, 15, 12, 00)));
            stations.Add(new TrainStation("Den Haag Laan ", "6", new DateTime(2020, 01, 01, 01,21, 10), new DateTime(2020, 04, 03, 02, 14, 10)));
           
            currentStationn = 0;
            direction = true;
            currentStation = stations[currentStationn];
            
        }


     
        public void RemoveObserver(ITrainDisplay observer)
        {
            Observ.Remove(observer);
        }
        public void AddObserver(ITrainDisplay observer)
        {
            Observ.Add(observer);
        }
        public void NextStation()
        {
            currentStation = stations[currentStationn];

            if (currentStationn == stations.Count - 1)
                direction = false;

            else if (currentStationn == 0)
                direction = true;

            if (direction)
                currentStationn++;
            else
                currentStationn--;

            NotifyObservers();
        }

        private void NotifyObservers()
        {
            foreach (ITrainDisplay station in Observ)
            {
                station.Update(currentStation);
            }
        }
    }
}
