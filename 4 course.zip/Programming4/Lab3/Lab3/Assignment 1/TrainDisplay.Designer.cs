﻿namespace Assignment_1
{
    partial class TrainDisplay
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Current = new System.Windows.Forms.Label();
            this.Railway = new System.Windows.Forms.Label();
            this.Arrival = new System.Windows.Forms.Label();
            this.Departure = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(87, 81);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(111, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Current Station: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(87, 122);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Railway Track: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(87, 179);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(91, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Arrival Time: ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(87, 221);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(115, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "Departure Time: ";
            // 
            // Current
            // 
            this.Current.AutoSize = true;
            this.Current.Location = new System.Drawing.Point(229, 81);
            this.Current.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Current.Name = "Current";
            this.Current.Size = new System.Drawing.Size(72, 17);
            this.Current.TabIndex = 4;
            this.Current.Text = "________";
            // 
            // Railway
            // 
            this.Railway.AutoSize = true;
            this.Railway.Location = new System.Drawing.Point(229, 122);
            this.Railway.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Railway.Name = "Railway";
            this.Railway.Size = new System.Drawing.Size(72, 17);
            this.Railway.TabIndex = 5;
            this.Railway.Text = "________";
            // 
            // Arrival
            // 
            this.Arrival.AutoSize = true;
            this.Arrival.Location = new System.Drawing.Point(229, 179);
            this.Arrival.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Arrival.Name = "Arrival";
            this.Arrival.Size = new System.Drawing.Size(72, 17);
            this.Arrival.TabIndex = 6;
            this.Arrival.Text = "________";
            // 
            // Departure
            // 
            this.Departure.AutoSize = true;
            this.Departure.Location = new System.Drawing.Point(229, 221);
            this.Departure.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Departure.Name = "Departure";
            this.Departure.Size = new System.Drawing.Size(72, 17);
            this.Departure.TabIndex = 7;
            this.Departure.Text = "________";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(138, 19);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(119, 17);
            this.label5.TabIndex = 8;
            this.label5.Text = "Train SCHEDULE";
            // 
            // TrainDisplay
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(445, 330);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Departure);
            this.Controls.Add(this.Arrival);
            this.Controls.Add(this.Railway);
            this.Controls.Add(this.Current);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "TrainDisplay";
            this.Text = "TrainDisplay";
            this.Load += new System.EventHandler(this.TrainDisplay_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label Current;
        private System.Windows.Forms.Label Railway;
        private System.Windows.Forms.Label Arrival;
        private System.Windows.Forms.Label Departure;
        private System.Windows.Forms.Label label5;
    }
}