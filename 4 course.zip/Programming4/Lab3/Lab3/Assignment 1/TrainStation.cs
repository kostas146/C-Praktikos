﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_1
{
    public class TrainStation
    {
        public DateTime ArrivalTime;
        public DateTime DepartureTime;

        public string Name;
        public string ArrivalTrack;
  
        public TrainStation(string name, string arrivalT, DateTime arrTime, DateTime depTime)
        {
            Name = name;

            ArrivalTrack = arrivalT;

            ArrivalTime = arrTime;

            DepartureTime = depTime;
        }

        
    }
}
