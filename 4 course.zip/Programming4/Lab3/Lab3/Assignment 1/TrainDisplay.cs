﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment_1
{
    public partial class TrainDisplay : Form, ITrainDisplay
    {

        public TrainDisplay()
        {
            InitializeComponent();
        }

        public void Update(TrainStation station)
        {
            Current.Text = station.Name;
            Arrival.Text = station.ArrivalTime.ToString();
            Departure.Text = station.DepartureTime.ToString();
            Railway.Text = station.ArrivalTrack;
          
        }

        private void TrainDisplay_Load(object sender, EventArgs e)
        {

        }
    }
}
