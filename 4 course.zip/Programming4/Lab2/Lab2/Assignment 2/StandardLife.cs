﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConwayGameOfLife
{
    public class StandardLife : ILifeBehaviour
    {
        public bool CellShouldLive(bool live, int neighCount)
        {
           if (live && neighCount == 2)
           return true;
           if (neighCount == 3)
           return true;  
        
           return false;
        }
    }
}
