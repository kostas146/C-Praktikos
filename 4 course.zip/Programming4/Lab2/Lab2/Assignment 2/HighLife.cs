﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConwayGameOfLife
{
    class HighLife : ILifeBehaviour
    {
        public bool CellShouldLive(bool living, int neighbCount)
        {
          
            if (living && (neighbCount == 2 || neighbCount == 3))
                return true;
            if (neighbCount == 3 || neighbCount == 6)
                return true;

            return false;
        }
    }
}
