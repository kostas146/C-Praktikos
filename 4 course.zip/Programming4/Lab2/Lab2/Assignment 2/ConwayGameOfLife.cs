﻿using System;
using System.Drawing;

namespace ConwayGameOfLife
{
  public class ConwayGameOfLife
  {
        
    public ILifeBehaviour lifeBehaviour;
        const int HEIGHT = 140;
        const int WIDTH = 300;

        const int LIVECHANCE = 20;

    private bool[,] space;
        SolidBrush dead = new SolidBrush(Color.LightGray);
        SolidBrush live = new SolidBrush(Color.Red);
   

    public ConwayGameOfLife()
    {
      this.space = new bool[HEIGHT, WIDTH];
      InitializeLife();
    }

   
    private void InitializeLife()
    {
      Random random = new Random(DateTime.Now.Millisecond);
      for (int r = 0; r < HEIGHT; r++)
      {
      for (int c = 0; c < WIDTH; c++)
        {
          this.space[r, c] = (random.Next(1, (100 / LIVECHANCE)) == 1);
        }
      }
    }

    public void Reset()
    {
      InitializeLife();
    }

    public void Draw(Graphics g)
    {
      Rectangle rec = new Rectangle(0, 0, 4, 4);

      for (int k = 0; k < HEIGHT; k++)
      {
        for (int b = 0; b < WIDTH; b++)
                { 
        rec.Location = new Point(b * 5, k * 5);

        if (this.space[k, b])
        g.FillRectangle(live, rec);
        else
        g.FillRectangle(dead, rec);
        }
      }
    }

    
    public void Evolve()
    {
        bool[,] copySpace = new bool[HEIGHT, WIDTH];
      for (int k = 0; k < HEIGHT; k++)
        for (int b = 0; b < WIDTH; b++)
          copySpace[k, b] = this.space[k, b];

      
      for (int k = 0; k < HEIGHT; k++)
      {
        for (int b = 0; b < WIDTH; b++)
        {
          bool livingCell = copySpace[k, b];
          int neighBourCount = GetLiveNeighbours(copySpace, k, b);
          this.space[k, b] = lifeBehaviour.CellShouldLive(livingCell, neighBourCount);
        }
      }
    }


    private int GetLiveNeighbours(bool[,] space, int row, int column)
    {
      int counter = 0;

      for (int a = -1; a <= 1; a++)
      {
        for (int b = -1; b <= 1; b++)
        {
          if ((a == 0) && (b == 0)) continue;
         int a2 = row + a;
          if (a2 < 0)
            a2 += HEIGHT;
          else if (a2 >= HEIGHT)
            a2 -= HEIGHT;

          int b2 = column + b;
          if (b2 < 0)
            b2 += WIDTH;
          else if (b2 >= WIDTH)
            b2 -= WIDTH;

          if (space[a2, b2])
                        counter++;
        }
      }

      return counter;
    }
  }
}