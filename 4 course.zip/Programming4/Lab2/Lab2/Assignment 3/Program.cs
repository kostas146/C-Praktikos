﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Program my = new Program();
            my.Start();
        }

        void Start()
        {
            IObservable player = new MP3Player();
            IObserver player1 = new SimpleMP3Display(player);
            IObserver player2 = new FancyMP3Display(player);
            player.NextSong();
            player.NextSong();
            player.NextSong();
          
        }
    }
}
