﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_3
{
    class MP3Player : IObservable
    {
        private List<Song> songList = new List<Song>();

        Random rnd = new Random();

        public MP3Player()
        {
            songList.Add(new Song("P.Floyd", "Wish You Were Here", 3, 33));
            songList.Add(new Song("L. Zeppelin", "Dazed Confused", 3, 12));
            songList.Add(new Song("B.Mars", "Billionaire", 4, 0));

        }

        public Song CurrentSong { get; set; }
        private List<IObserver> MP3Displays = new List<IObserver>();

        public void AddObserver(IObserver observer)
        {
            MP3Displays.Add(observer);
        }

        public void NextSong()
        {

            CurrentSong = songList[rnd.Next(songList.Count)];
            NotifyObservers();
        }

        public void RemoveObserver(IObserver observer)
        {
            MP3Displays.Remove(observer);
        }

        void NotifyObservers()
        {
            foreach (IObserver Song in MP3Displays)
            { Song.Update(CurrentSong); }
        }
    }
}
