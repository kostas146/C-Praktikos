﻿// antras.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

int main()
{

    int skaicius;
    std::cout << "Iveskite skaiciu: ";
    std::cin >> skaicius;
    int arr[100];
    int visoskaiciu = 0;
    int liekana;

    // kol pasieks 0
    while (skaicius != 0) {

        // liekana
        liekana = skaicius % 10;

        // liekan i array
        arr[visoskaiciu] = liekana;
        visoskaiciu++;

        // numetam paskutini skaiciu nuo pradinio
        skaicius = skaicius / 10;
    }
    // issrasom nuo galo.
    for (int j = visoskaiciu - 1; j > -1; j--) {
        std::cout << arr[j] << arr[j];
    }

}


//2.     Parašykite programą, kuri padvigubinų duoto natūraliojo skaičiaus n skaitmenis.Pvz. : Jei n = 1986, tai rezultatas turi būti n = 11998866.
