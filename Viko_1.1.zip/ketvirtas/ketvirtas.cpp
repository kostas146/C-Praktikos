﻿// ketvirtas.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

int main()
{
    int suma;
    std::cout << "iveskite suma: ";
    std::cin >> suma;
    double atlyg=0;
    if (suma <= 5000)
    {
        atlyg = suma * 0.1;
        std::cout << "atlyginimas: " << atlyg;
    }
    else if (suma > 5000 && suma < 10000)
    {
        atlyg = suma * 0.2;
        std::cout << "atlyginimas: " << atlyg;
    }
    else if (suma > 10000 && suma <15000)
    {
        atlyg = suma * 0.25;
        std::cout << "atlyginimas: " << atlyg;
    }
    else if (suma >= 15000)
    {
        atlyg = suma * 0.3;
        std::cout << "atlyginimas: " << atlyg;
    }
       
}

//4. Pardavėjas gauna atlygį už darbą pagal pardavimus.T.y.pardavęs prekių už <= 5000 eurų, nuo šios sumos pardavėjas gauna 10 proc.,
//pardavęs prekių daugiau kaip už 5000, bet ne daugiau nei 10000 eurų, nuo šios sumos jis gauna 20 proc.Jei įvykdo pardavimų už > 10000 eur.,|
//gauna 25 proc.nuo pardavimų sumos.Parašykite programą, kuri paskaičiuotų, kokį atlygį gaus pardavėjas, kuomet žinoma jo įvykdytų pardavimų 
//suma.
