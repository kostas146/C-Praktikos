﻿// antras.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

int main()
{
    int x, z, y;
    std::cout << "Iveskite 3 skaicius\n";
    std::cout << "1 skaicius\n";
    std::cin >> x;
    std::cout << "2 skaicius\n";
    std::cin >> y;
    std::cout << "3 skaicius\n";
    std::cin >> z;
    int maziausas = 99999;

    if (x < maziausas)
        maziausas = x;
    if (y < maziausas)
        maziausas = y;
    if (z < maziausas)
        maziausas = z;

    std::cout << "maziausias skaicius" << maziausas;
}


//2.     Parašykite programą, kuri įvedus tris skaičius, nustatytų, kuris iš jų yra mažiausias.


