﻿using System;

namespace Assignment_2_DECKOFCARDS
{
    class Program
    {
        static void Main(string[] args)
        {
            Program myProgram = new Program();

            myProgram.start();
        }
        void start()
        {
            DeckOfcardss deck = new DeckOfcardss();
          
            deck.Print();

            deck.Shuffle();

            Console.WriteLine("\n \n \n SHUFFLED \n \n \n ");


            deck.Print();

        }
    }
}