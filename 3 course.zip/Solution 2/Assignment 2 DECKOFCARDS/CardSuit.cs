﻿namespace Assignment_2_DECKOFCARDS
{
    public enum CardSuit
    {
        Spades, Clubs, Hearts, Diamonds
    }
}