﻿using System;
using System.Collections.Generic;

namespace Assignment_2_DECKOFCARDS
{
    class DeckOfcardss
    {
        public List<PlayingCard> WholeDeck;
        public DeckOfcardss()
        {

            WholeDeck = new List<PlayingCard>();
            InitCards();

        }
        public void InitCards()
        {

            string[] allRanks = new string[] { "ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King" };

            foreach (CardSuit suit in (CardSuit[])Enum.GetValues(typeof(CardSuit)))
            {
                foreach (string rank in allRanks)
                {
                    WholeDeck.Add(new PlayingCard(suit, rank));
                }

            }

        }

        public void Print()
        {

            foreach (PlayingCard item in WholeDeck)
                Console.WriteLine(item.ToString());

        }

        public void Shuffle()
        {
            Random rnd = new Random();

            for (int i = WholeDeck.Count - 1; i > 0; --i)
            {
                int k = rnd.Next(i + 1);
                PlayingCard temp = WholeDeck[i];
                WholeDeck[i] = WholeDeck[k];
                WholeDeck[k] = temp;
            }
        }




    }
}