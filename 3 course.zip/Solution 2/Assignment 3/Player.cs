﻿using System.Collections.Generic;

namespace Assignment_3
{
    class Player
    {
        public string name;
        public List<PlayingCard> cards;

        public Player(string Name)
        {
            cards = new List<PlayingCard>();
            this.name = Name;
        }
        public void AddCard(PlayingCard card)
        {
            cards.Add(card);
        }
        public PlayingCard GetNextCard()
        {
            PlayingCard TakenCard = cards[0];
            cards.RemoveAt(0);
            return TakenCard;
        }
    }
}
