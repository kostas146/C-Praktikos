﻿namespace Assignment_3
{
    public enum CardSuit
    {

        Spades, Clubs, Hearts, Diamonds
    }
}

