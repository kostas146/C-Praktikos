﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment_3
{
    class DeckOfcards
    {

        public List<PlayingCard> WholeDeck;
        public DeckOfcards()
        {

            WholeDeck = new List<PlayingCard>();
            InitCards();

        }
        public void InitCards()
        {

            string[] allRanks = new string[] { "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King", "ACE" };
            int z = 0;
            foreach (CardSuit suit in (CardSuit[])Enum.GetValues(typeof(CardSuit)))
            {
                foreach (string rank in allRanks)
                {
                    WholeDeck.Add(new PlayingCard(suit, rank));

                        z++;
                    
                }

            }
            Console.WriteLine(z);
        }

        public void Print()
        {

            foreach (PlayingCard item in WholeDeck)
                Console.WriteLine(item.ToString());

        }

        public void Shuffle()
        {
            Random rnd = new Random();

            for (int i = WholeDeck.Count - 1; i > 0; --i)
            {
                int k = rnd.Next(i+1);
                PlayingCard temp = WholeDeck[i];
                WholeDeck[i] = WholeDeck[k];
                WholeDeck[k] = temp;
            }
        }


    }
}
