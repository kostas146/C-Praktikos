﻿namespace Assignment_3
{
    class CardGame
    {
        public DeckOfcards deck;
        public CardGame()
        {
            deck = new DeckOfcards();
        }
    }
}
