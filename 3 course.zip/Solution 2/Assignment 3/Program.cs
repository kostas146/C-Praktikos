﻿using System;

namespace Assignment_3
{
    class Program
    {
        static void Main(string[] args)
        {

            Program myProgram = new Program();

            myProgram.start();
        }
        void start()
        {
            Player player1 = new Player("Mr.Hacker");
            Player player2 = new Player("Mr.Scammer");
            WarCardGame war = new WarCardGame(player1, player2);
            PlayTheGame(war);


        }
        void PlayTheGame(WarCardGame war)
        {
            war.StartNewGame();
            while (!war.EndOfGame())
            {
                war.NextCard();
            }

            wins(war);
            Console.ReadKey();
        }
        void wins(WarCardGame war)
        {
            //  Console.ResetColor();
            Console.WriteLine();
            if (war.player1.cards.Count == 0)
            {
                Console.WriteLine("{0} HAS WON THE GAME!!", war.player1.name);
            }
            else
            {
                Console.WriteLine("{0} HAS WON THE GAME!!", war.player2.name);
            }



        }
    }
}
