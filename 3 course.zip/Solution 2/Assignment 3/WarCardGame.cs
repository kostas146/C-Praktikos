﻿using System;

namespace Assignment_3
{
    class WarCardGame : CardGame
    {
        public Player player1;
        public Player player2;

        public WarCardGame(Player p1, Player p2)
        {
            this.player1 = p1;
            this.player2 = p2;
        }
        public void StartNewGame()
        {
            deck.Shuffle();
            for (int i = 0; i < deck.WholeDeck.Count; i++)
            {
                if (i % 2 == 0) // 1/2 != 0;(P2) 2/2 = 0(P1); 3/2!=0(P2); 4%2=0(P1) // quick MATHS
                {

                    player1.AddCard(deck.WholeDeck[i]);
                }
                else
                {

                    player2.AddCard(deck.WholeDeck[i]);
                }
            }
        }
        public bool EndOfGame()
        {
            if (player1.cards.Count == 0 || player2.cards.Count == 0)
            { return true; }
            return false;
        }
        public void NextCard()
        {
            PlayingCard card1 = player1.GetNextCard();
            PlayingCard card2 = player2.GetNextCard();

            Console.ResetColor();
            Console.WriteLine("[{0}] {1} of {2} - [{3}] {4} of {5}", player1.name, card1.rank, card1.suit, player2.name, card2.rank, card2.suit);

            string[] allRanks = new string[] { "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King", "ACE" };
            int card1Val = Array.IndexOf(allRanks, card1.rank);
            int card2Val = Array.IndexOf(allRanks, card2.rank);
            if (card1Val > card2Val)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("{0} WON", player1.name);
                player1.AddCard(card1);
                player1.AddCard(card2);


            }
            if (card1Val == card2Val)
            {

                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("2 CARDS WERE LOST");
                Console.WriteLine("Cards left: [{0}] {1}x, of [{2}] {3}x", player1.name, player1.cards.Count, player2.name, player2.cards.Count);

            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("{0} WON", player2.name);
                player2.AddCard(card1);
                player2.AddCard(card2);

            }
        }




    }
}

