﻿using System;
using System.Collections.Generic;

namespace Assignment_1
{

    abstract class BookStoreItem
    {
        protected string title;
        protected int price;
        public BookStoreItem(string Title, int Price)
        {
            this.title = Title;
            this.price = Price;
        }

        public abstract void Print();

        public double Calculate()
        {
            return price;
        }




    }

    class Magazine : BookStoreItem
    {
        public string date;

        public Magazine(string date, string title, int price)
            : base(title, price)
        {
            this.date = date;
        }
        public override void Print()
        {
            Console.WriteLine("Date: " + date + "Title: " + title + "Price: " + price);
        }
    }


    class Book : BookStoreItem
    {

        string author;

        public Book(string title, string author, int price)
            : base(title, price)
        {
            this.author = author;

        }
        public override void Print()
        {
            Console.WriteLine("Title: " + title + "Author: " + author + "Price: " + price);

        }


    }

    class BookStore

    {

        List<BookStoreItem> item = new List<BookStoreItem>();


        public void Add(BookStoreItem _item)
        {
            item.Add(_item);
        }
        public void PrintCompleteStock()
        {
            foreach (BookStoreItem item in item)
            {


                item.Print();

            }

        }

    }
}
