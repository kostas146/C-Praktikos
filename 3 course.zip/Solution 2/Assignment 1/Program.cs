﻿using System;

namespace Assignment_1
{
    class Program
    {
        static void Main(string[] args)
        {

            Program myProgram = new Program();

            myProgram.start();
        }
        void start()
        {
            BookStore BookList = new BookStore();
            Book Book1 = new Book("John", " Losing The King", 7);
            Book Book2 = new Book("Tom", " History Of The Light", 7);
            Book Book3 = new Book("Matt", " Slaves With Silver", 7);
            Magazine mag = new Magazine(" 20/15/20", " Brigit ", 8);
            BookList.Add(Book1);
            BookList.Add(Book2);
            BookList.Add(Book3);
            BookList.Add(mag);
            double Total = Book1.Calculate() + Book2.Calculate() + Book3.Calculate() + mag.Calculate();
            BookList.PrintCompleteStock();
            Console.WriteLine("Total: " + Total);


        }
    }
}
