﻿using System;
using System.Collections.Generic;

namespace Assignment_2
{
    class Program
    {
      
            static void Main(string[] args)
            {
                Program myprogram = new Program();
                myprogram.Start();
            }

            void Start()
            {
            Customer test = new Customer("Kostas", new DateTime(2000, 11, 18));
            test.PrintCustomer(test);
         

            //CHECK
            string namee = "Big Ben";
            int room = 4;
            DateTime MS = new DateTime(2020, 5, 29, 15, 30, 20);
            decimal price = 8.25M;
            int age = 9;

            Ticket tickettest = new Ticket(namee, room, MS, price, age);



            tickettest.Print(tickettest);
            



            List<Ticket> tickets = new List<Ticket>();          // creating reservation and adding a ticket to it
            tickets.Add(tickettest);
            
            Reservation reservation = new Reservation(test, tickets);

            Console.WriteLine("\n Total price: "+reservation.TotalPrice);          // checking the total price for reservation
            Console.ReadKey();
           
            }

    } 
} 
