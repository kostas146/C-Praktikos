﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment_2
{
    class Ticket
    {
        private string movieName;
        private int cinemaRoom;
        private DateTime startTime;
        private decimal price;
        private int minimumAge;

        public Ticket(string Name, int Room, DateTime starTime, decimal prices, int minimumage) //construct
        {
            this.MovieName = Name;
            this.CinemaRoom = Room;
            this.StartTime = starTime;
            this.price = prices;
            this.MinimumAge = minimumage;

        }
        public string MovieName // prop
        {
            get { return movieName; }
            set
            {
                if (value == " ")
                {
                    throw new System.Exception("Name cannot be empty");
                }
                else
                {
                    movieName = value;
                }
            }
        }

        public decimal actual
        {
            get { return price; }
            set { price = value; }
        }

  
        public int CinemaRoom // prop
        {
            get { return cinemaRoom; }
            set
            {
                if ((value == 1) || (value == 2) || (value == 3) || (value == 4) || (value == 5))
                    cinemaRoom = value;
                else
                 throw new System.Exception("Invalid Room!"); 
            }
            
        }

        public DateTime StartTime
        {
            get { return startTime; }
            set
            {
                if ((value.Minute == 30) || (value.Minute == 00))
                {
                    startTime = value;
                }
                else
                    throw new System.Exception("All movies should start :30 or:00");
            }
        }
    
        
     
        public int MinimumAge
        {
            get { return minimumAge; }
            set
            {
                if ((value == 0) || (value == 6) || (value == 9) || (value == 12) || (value == 16))
                {
                    minimumAge = value;
                }
                else
                    throw new System.Exception("Invalid age ");

            }
        }

        public bool Discount
        {
            get
            {
                if ((DateTime.Now.DayOfWeek == DayOfWeek.Monday) || (DateTime.Now.DayOfWeek == DayOfWeek.Tuesday))
                {
                    return true;
                }
                else
                    return false;
            }

        }
        

        public void Print(Ticket k)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(k.MovieName);
            Console.ResetColor();
            Console.WriteLine("Movie name : " + k.MovieName + "\n Cinema Room number: " + k.CinemaRoom + "\n Starttime : " + k.StartTime.ToString() + "\n Price : " + k.actual + "\n Minimum age : " + k.MinimumAge);


        }


    }

}

