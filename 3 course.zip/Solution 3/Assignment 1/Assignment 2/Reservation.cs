﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment_2
{
    class Reservation
    {
        private Customer customer;

        private List<Ticket> Tickets;

        public Reservation(Customer customer, List<Ticket> ticketlist)
        {
            this.customer = customer;
            this.Tickets = ticketlist;
        }
        public decimal TotalPrice
        {
            get
            {
                decimal totalprice = 0.0M;
                foreach (Ticket ticket in Tickets)
                {
                   if ((this.customer.Discount == true) && (ticket.Discount == true))
                   {
                       totalprice += (ticket.actual - (ticket.actual / 100*5) - (ticket.actual /100*10));
                   }
                   else if (this.customer.Discount == true)
                   {
                       totalprice += (ticket.actual - (ticket.actual / 100*10));
                   }
                   else if (ticket.Discount == true)
                   {
                       totalprice += (ticket.actual - (ticket.actual / 100 * 5));
                   }
                    else
                     totalprice = ticket.actual;
                }
                return totalprice;
            }
        }
    }

}

