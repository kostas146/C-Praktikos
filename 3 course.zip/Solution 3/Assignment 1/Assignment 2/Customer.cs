﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment_2
{
    class Customer
    {
        private string name;
        private DateTime Date;

        public Customer(string name, DateTime dateofbirth)
        {
            this.Name = name;
            this.DateOfBirth = dateofbirth;
        }

        public string Name
        {
            get { return name; }

            set
            {
                if (value != "")
                    name = value;
                else
                    name = "Please write your name.";
            }
        }
        public DateTime DateOfBirth
        {
            get { return Date; }
            set
            {
                if (DateTime.Compare(value, DateTime.Now) < 0 && DateTime.Compare(value, new DateTime(1910, 1, 1, 0, 0, 0)) > 0)
                    Date = value;
            }
        }

        public DateTime DateOfReg
        {
            get { return DateTime.Now; }

        }
        public static int AgeInYears(DateTime birthday, DateTime today)
        {
            return ((today.Year - birthday.Year) * 372 + (today.Month - birthday.Month) * 31 + (today.Day - birthday.Day)) / 372;
        }

        public int Age
        {
            get {return AgeInYears(DateOfBirth, DateTime.Now); }
        }
    public bool Discount
        {
            get
            {
                if (DateTime.Now.Year - this.DateOfReg.Year < 2)
                    return false;
                else
                    return true;
            }
          
        }
        public void PrintCustomer(Customer k)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(k.Name);
            Console.ResetColor();
            Console.WriteLine("Date of Birth : " + k.DateOfBirth.ToString("dd/MM/yyyy") + "\nAge : " + k.Age + "\nDate of Registration : " + k.DateOfReg.ToString("dd/MM/yyyy") + "\nDiscount : " + k.Discount);


        }
    }
}