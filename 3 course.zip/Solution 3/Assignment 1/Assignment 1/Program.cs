﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Program myprogram = new Program();
            myprogram.Start();
        }

        void Start()
        {
            BookStore List = new BookStore();
            Book book1 = new Book("Feeling good man", "Doctar", 75, 4);
            Book book2 = new Book("Something", "Something1",18 , 6);
            Magazine magazine1 = new Magazine("People", "person", 63, 2);
            Magazine magazine2 = new Magazine("Joker", "Batman", 45, 8);
            Book book3 = new Book("Monkey", "Gorilla", 3, 4);

            List.Add(book1);
            List.Add(book2);
            List.Add(book3);
            List.Add(magazine1);
            List.Add(magazine2);

            List.PrintEveryBook();
            Console.WriteLine();
            List.PrintCompleteStock();
            Console.ReadKey();
        }
    }
}

