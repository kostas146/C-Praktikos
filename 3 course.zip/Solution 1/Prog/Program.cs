﻿using System;

namespace Prog
{
    class Program
    {
        static void Main(string[] args)
        {
            Program myProgram = new Program();
            
            myProgram.start();
        }
        void start()
        {
            Team myTeam = new Team();


            Programmer person = new Programmer("Peter", Speciality.Csharp);
            Programmer person1 = new Programmer("Kim", Speciality.PHP); 
            Programmer person2 = new Programmer("Win", Speciality.Java);
            Programmer person3 = new Programmer("Bean", Speciality.Html);
            Programmer Kostas = new Programmer("Kostas");

            myTeam.AddToList(person);
            myTeam.AddToList(person1);
            myTeam.AddToList(person2);
            myTeam.AddToList(person3);
            myTeam.AddToList(Kostas);
            myTeam.PrintAllTeamMembers();

          





        }
    }
}
