﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Prog
{
    public class Team
    {
        List<Programmer> programmers;
        public Team()
        {

            programmers = new List<Programmer>();
         

        }
        public void AddToList(Programmer person)
        {
            programmers.Add(person);
        }

        public  void PrintAllTeamMembers()
        {

           foreach (Programmer p in programmers)
            {
                Programmer.Print(p);
            }
        }
    }
}