﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Prog
{
    public class Programmer
    {
        string name;
        Speciality specs;
        public Programmer(string Name, Speciality special)
        {
            this.name = Name;
            this.specs = special;

        }
        public Programmer(string Name) 
            :this (Name, Speciality.unkown)
        {
            
        }
       public static void Print(Programmer programmer)
        {
            Console.WriteLine("Name: {0}, Speciality: {1} ", programmer.name, programmer.specs) ;
          
        }
       
    }
}