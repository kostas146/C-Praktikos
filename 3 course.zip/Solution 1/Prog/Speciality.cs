﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Prog
{
    public enum Speciality
    {
        Java , Csharp, Html, PHP, unkown
    }
}