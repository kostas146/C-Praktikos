﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Yahtzee
{
    public class YahtzeeGame
    {
        Dice[] dices = new Dice[5];

        public YahtzeeGame()
            {
            
            for (int i = 0; i < dices.Length; i++)
            {
                Random rnd = new Random();
                dices[i] = new Dice(rnd);
            }
           
        }
     
        public void Throwing()
        {
            for (int i = 0; i < dices.Length; i++)
            {
                dices[i].Throw();
            }
        }



        public void DisplayValues()
        {
            for (int i = 0; i < dices.Length; i++)
            {
                dices[i].DisplayValue();
            }

        }
        public bool Yahtzee()
        {
            int a = 0;
            int first = dices[0].value;
            int second = dices[1].value;
            int third = dices[2].value;
            int fourth = dices[3].value;
            int fifth = dices[4].value;
            if (first == second & second == third & third == fourth & fourth == fifth)
            {
                a++;
            }


            if (a > 0)
                return true;
            else
                return false;
        }
    }
}