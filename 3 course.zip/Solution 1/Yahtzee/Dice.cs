﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Yahtzee
{
    public class Dice
    {

        public int value;
        Random rnd = new Random();

        public Dice(Random rnd)
        {
            this.value = rnd.Next(1, 7);
        }

      

        public void Throw()
            
        {
            value = rnd.Next(1, 7);
        }
        public void DisplayValue()
        {
            Console.Write(value + " ");
        }
    }
}