﻿using System;

namespace Assign2
{
    public class Position
    {
        public int row = 0;
        public int column = 0;
    }
    public class Program
    {
        static void Main(string[] args)
        {
            Program program = new Program();
            program.Start();

        }

        void Start()
        {
            int[,] matrix = new int[10, 10];

            InitMatrixRandom(matrix, 0, 100);
            DisplayMatrix(matrix);
            Position position;
            int number;
            do
            {
                Console.Write("\n Enter a number(to search for): ");
                number = int.Parse(Console.ReadLine());
                position = SearchNumber(matrix, number);
                Console.WriteLine("Number {0} is found at the (first) position [{1},{2}] ", number, position.row, position.column);
                position = SearchNumberBackwards(matrix, number);
                Console.WriteLine("Number {0} is found at the (last) position [{1},{2}] ", number, position.row, position.column);
            }
            while (position.row == -1);


            Console.ReadKey();
        }

        void InitMatrixRandom(int[,] matrix, int min, int max)
        {
            Random rnd = new Random();
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    matrix[i, j] = rnd.Next(min, max);
                }

            }
        }
        void DisplayMatrix(int[,] matrix)
        {
            for (int row = 0; row < matrix.GetLength(0); row++)
            {
                Console.WriteLine();
                for (int col = 0; col < matrix.GetLength(1); col++)
                {
                    Console.Write("{0,5} ", matrix[row, col]);
                }
            }
        }
        Position SearchNumber(int[,] matrix, int number)
        {
            Position position = new Position();
            position.row = 0;
            position.column = 0;
            for (int row = 0; row < matrix.GetLength(0); row++)
            {
                for (int col = 0; col < matrix.GetLength(1); col++)
                {
                    if (matrix[row, col] == number)
                    {
                        position.row = row;
                        position.column = col;
                        return position;
                    }

                }
            }
            return position;

        }
        Position SearchNumberBackwards(int[,] matrix, int number)
        {
            Position position = new Position();
            position.row = -1;
            position.column = -1;
            for (int row = matrix.GetLength(0) - 1; row >= 0; row--)
            {
                for (int col = matrix.GetLength(1) - 1; col >= 0; col--)
                {
                    if (matrix[row, col] == number)
                    {
                        position.row = row;
                        position.column = col;
                        return position;
                    }

                }
            }
            return position;
        }
    }
}