﻿using System;

namespace Assign3
{
    enum RegularCandies { JellyBean = 1, Lozenge, LemonDrop, GumSquare, LollipopHead, JujebeCluster }
    class Program
    {
        static void Main(string[] args)
        {
            Program program = new Program();
            program.Start();
        }

        void Start()
        {
            //2 d. arr of type RegularCandies
            RegularCandies[,] playingField = new RegularCandies[6, 6];
            InitCandies(playingField);
            DisplayCandies(playingField);
            ScoreRowPresent(playingField);
            ScoreColumnPresent(playingField);
        }

        void InitCandies(RegularCandies[,] playingField)
        {
            Random rnd = new Random();

            for (int row = 0; row < playingField.GetLength(0); row++)
            {
                for (int col = 0; col < playingField.GetLength(1); col++)
                {

                    playingField[row, col] = (RegularCandies)rnd.Next(1, 7);

                }

            }

        }

        void DisplayCandies(RegularCandies[,] playingField)
        {

            for (int row = 0; row < playingField.GetLength(0); row++)
            {

                for (int col = 0; col < playingField.GetLength(1); col++)
                {
                    RegularCandies candies = playingField[row, col];
                    switch (candies)
                    {
                        case RegularCandies.JellyBean:
                            Console.ForegroundColor = ConsoleColor.Red;
                            break;
                        case RegularCandies.Lozenge:
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            break;
                        case RegularCandies.LemonDrop:
                            Console.ForegroundColor = ConsoleColor.Yellow;
                            break;
                        case RegularCandies.GumSquare:
                            Console.ForegroundColor = ConsoleColor.Green;
                            break;
                        case RegularCandies.LollipopHead:
                            Console.ForegroundColor = ConsoleColor.Blue;
                            break;
                        case RegularCandies.JujebeCluster:
                            Console.ForegroundColor = ConsoleColor.White;
                            break;

                    }
                    Console.Write("{0,2}", "#");
                    Console.ResetColor();
                }
                Console.WriteLine();

            }

        }
        bool ScoreRowPresent(RegularCandies[,] playingField)
        {
            for (int row = 0; row < playingField.GetLength(0); row++)
            {

                int count = 1;

                for (int col = 1; col < playingField.GetLength(1); col++)
                {
                    RegularCandies currCandies = playingField[row, col];
                    RegularCandies NextCandies = playingField[row, col - 1];
                    if (currCandies == NextCandies)
                    {
                        count++;
                        if (count >= 3)
                        {
                            Console.WriteLine("Row score!");
                            return true;
                        }

                    }
                    else
                    {
                        count = 1;
                    }
                }
            }
            Console.WriteLine("No row score! :((");
            return false;
        }
        bool ScoreColumnPresent(RegularCandies[,] playingField)
        {

            for (int col = 0; col < playingField.GetLength(0); col++)
            {

                int count = 1;

                for (int row = 1; row < playingField.GetLength(1); row++)
                {
                    RegularCandies currCandies = playingField[row, col];
                    RegularCandies NextCandies = playingField[row - 1, col];
                    if (currCandies == NextCandies)
                    {
                        count++;
                        if (count >= 3)
                        {
                            Console.WriteLine("Column score! :)");
                            return true;
                        }

                    }
                    else
                    {
                        count = 1;
                    }
                }

            }
            Console.WriteLine("No Column score!! :(");
            return false;
        }
    }
}