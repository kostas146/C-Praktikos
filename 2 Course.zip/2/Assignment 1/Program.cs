﻿using System;

namespace Assignment_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Program myprogram = new Program();
            int[,] matrix = new int[8, 8];
            myprogram.InitMatrix2D(matrix);
            myprogram.DisplayMatrix(matrix);

            int[,] matrix2 = new int[11, 11];
            myprogram.InitMatrixLinear(matrix2);
            myprogram.DisplayMatrixWithCross(matrix2);
            Console.ReadKey();
        }


        void InitMatrix2D(int[,] matrix)
        {
            int count = 0;
            int n = matrix.GetLength(0) * matrix.GetLength(1);
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    count++;
                    if (count <= n)
                        matrix[i, j] = count;
                }
            }
            // Console.Write(count);
        }

        void DisplayMatrix(int[,] matrix)
        {
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    Console.Write(string.Format("{0,5}", matrix[i, j] + " "));

                }
                Console.WriteLine();
            }
        }


        void InitMatrixLinear(int[,] matrix2)
        {
            int row = matrix2.GetLength(0);
            int col = matrix2.GetLength(1);
            for (int i = 0; i < row * col; i++)
            {
                matrix2[i / col, i % col] = i + 1; // ONE LOOP MULTI DIMENSION 
            }
        }
        void DisplayMatrixWithCross( int[,] matrix2)
        {
            for (int x = 0; x < matrix2.GetLength(0); x++)
            {
                for (int y = 0; y < matrix2.GetLength(1); y++)
                {
                    if (x == y)
                    { Console.ForegroundColor = ConsoleColor.Red; }
                    if (y == matrix2.GetLength(1) - (x + 1))
                    { Console.BackgroundColor = ConsoleColor.Yellow; }
                     Console.Write(string.Format("{0,5}", matrix2[x, y] + "  "));
                     Console.ResetColor(); }
                    Console.WriteLine();
                    }
                }

            }
        }
    