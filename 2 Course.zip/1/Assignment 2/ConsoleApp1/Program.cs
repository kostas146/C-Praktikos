﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Program program = new Program();
            program.Start();
        }

        void Start()
        {

           
            Person henk = ReadPerson();
            PrintPerson(henk);
            birthday(henk);
            PrintPerson(henk);

            Person pietje = ReadPerson();
            birthday(pietje);
            PrintPerson(pietje);
            Console.ReadKey();
        }

        void birthday(Person p)
        {
            p.age++;
        }


        Person ReadPerson()
        {
            Person newPerson = new Person();
            newPerson.age = ReadInt("Please enter a age", 0, 100);
            newPerson.lastname = ReadString("Please fill in lastname");
            newPerson.name = ReadString("Please enter in name");
            newPerson.city = ReadString("Please enter the city");
            newPerson.gender = ReadGender();
            return newPerson;
        }

        Gender ReadGender()
        {
            return (Gender)ReadInt("Please enter a gender 0 = male 1 = female..", 0, 1);

        }

        void PrintGender(Gender g)
        {
            if (g == Gender.male)
            {
                Console.WriteLine("Male");

            }
            else if (g == Gender.female)
            {
                Console.WriteLine("Female");
            }
     

        }

        void PrintPerson(Person p)
        {
            Console.WriteLine(p.name);
            Console.WriteLine(p.lastname);
            Console.WriteLine(p.city);
            Console.WriteLine(p.age);
            PrintGender(p.gender);

        }


        int ReadInt(string question, int min, int max)
        {
            Console.Write(question);
            int number = int.Parse(Console.ReadLine());
            if (number <= max && number >= min)
                return number;
            else
                return ReadInt(question, min, max);
        }

        string ReadString(string question)
        {
            Console.Write(question);
            return Console.ReadLine();
        }
    }
}

