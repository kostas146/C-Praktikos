﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    
        enum Gender { male, female, unisex }


        struct Person
        {
            public string name;
            public string lastname;
            public string city;
            public int age;
            public Gender gender;

        }
    }

