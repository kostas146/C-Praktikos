﻿using System;

namespace Assignment_1
{

    public class Program
    {
        static void Main(string[] args)
        {
            Program program = new Program();
            program.PrintMonths();
            program.ReadMonth("enter a month:");




            Console.ReadKey();

        }

        void PrintMonth(Month month)
        {
            Console.WriteLine(month);
        }
        void PrintMonths()
        {
            for (Month month = Month.January; month <= Month.December; month++)
            {
                Console.Write("  "+(int)month+".");
                PrintMonth(month);
            }
        }
        Month ReadMonth(string question)
        {

            Console.WriteLine("Enter a number");
            string a = Console.ReadLine();

            Month input = (Month)int.Parse(a);
            Console.WriteLine(a+"  "+input);
            if (int.Parse(a)>12 || int.Parse(a)<=1)
            {
                Console.WriteLine(a+"is not a valid value.");
            }
            
            return input;
            
        }
    }
}

        