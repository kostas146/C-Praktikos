﻿using System;

namespace Assignment_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Program myProgram = new Program();
            myProgram.Start();
        }
        void Start()
        {
            YahtzeeGame yahtzeeGame = new YahtzeeGame();
            yahtzeeGame.Init();
            PlayYahtzee(yahtzeeGame);
            Console.ReadKey();
           

        }
        void PlayYahtzee(YahtzeeGame game)
        {

            int nrOfAttempts = 0;
            do
            {
                game.Throwing();
                game.DisplayValues();
                Console.WriteLine();
                nrOfAttempts++;

            } while (!game.Yahtzee());

            Console.WriteLine("Number of attempts needed for Yahtzee:  "+ nrOfAttempts);
        }
    }
}
