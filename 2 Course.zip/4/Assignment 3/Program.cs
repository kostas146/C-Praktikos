﻿using System;

using System.IO;

namespace Assignment_3
{
    class Program
    {
        int CountingLines = 0;
        static void Main(string[] args)
        {
            Program myProg = new Program();
            myProg.start();
        }
        void start()
        {
            string word;         

            string fileName = "F:/UNIVERSITY/Programming/Programming 2/4/Assignment 3/tweets2018.txt";

            Console.WriteLine("Please enter the word : ");
            word = Console.ReadLine();
          SearchWordInFile(fileName, word);


            Console.WriteLine("\nNumber of lines: " + CountingLines);
        }
        bool WordInLine(string line, string word)
        {
           bool matches = line.IndexOf(word,0, StringComparison.OrdinalIgnoreCase) != -1;
            return matches;
        }

        int SearchWordInFile(string fileName, string word)
        {
            StreamReader reader = new StreamReader(fileName);
            
            while (!reader.EndOfStream)
            {
                string Line = reader.ReadLine();
              
                if (WordInLine(Line,word))            
                    {
                    DisplayWordInLine(Line, word);
                    CountingLines++;
                }
                
            }

                return CountingLines;
        }
        void DisplayWordInLine(string line, string word)
        {
     
            int Pos1 = line.IndexOf(word, StringComparison.OrdinalIgnoreCase);
            string TEMP = "";

            
            TEMP = line.Substring(0, Pos1);

            Console.Write(TEMP);

            Console.ForegroundColor = ConsoleColor.Red;

            TEMP = line.Substring(Pos1, word.Length);

            Console.Write(TEMP);

            Console.ResetColor();

            TEMP = line.Substring(Pos1 + word.Length);

            Console.WriteLine(TEMP);
        }

    }
}
