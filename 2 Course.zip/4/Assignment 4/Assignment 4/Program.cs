﻿using System;
using System.IO;

namespace Assign3
{
    enum RegularCandies { JellyBean = 1, Lozenge, LemonDrop, GumSquare, LollipopHead, JujebeCluster }
    class Program
    {
        const int rowsz = 9;
        const int colsz = 9;
        static void Main(string[] args)
        {
            Program program = new Program();
            program.Start();
        }

        void Start()
        {
            string file = "candycrush";

            //2 d. arr of type RegularCandies
            RegularCandies[,] playingField = new RegularCandies[rowsz, colsz];


            //Creates/displays in the program


            InitCandies(playingField);
            DisplayCandies(playingField);
            ScoreRowPresent(playingField);
            ScoreColumnPresent(playingField);


            //converts to NUMBERS/ENUMS
            Console.WriteLine();
            Console.WriteLine("Converting to numbers... ");
            WritePlayingFieldConsole(playingField);


            // Gets from program puts to TEXTFILE
            Console.WriteLine();
            Console.WriteLine("writing to the file...");
            WritePlayingField(playingField, file);

             //puts to console from text file 
            Console.WriteLine("Displaying from file...");
            DisplayCandies(ReadPlayingField(file));


            void InitCandies(RegularCandies[,] playingField)
            {
                Random rnd = new Random();

                for (int row = 0; row < playingField.GetLength(0); row++)
                {
                    for (int col = 0; col < playingField.GetLength(1); col++)
                    {

                        playingField[row, col] = (RegularCandies)rnd.Next(1, 7);

                    }

                }

            }

            void DisplayCandies(RegularCandies[,] playingField)
            {

                for (int row = 0; row < playingField.GetLength(0); row++)
                {

                    for (int col = 0; col < playingField.GetLength(1); col++)
                    {
                        RegularCandies candies = playingField[row, col];
                        switch (candies)
                        {
                            case RegularCandies.JellyBean:
                                Console.ForegroundColor = ConsoleColor.Red;
                                break;
                            case RegularCandies.Lozenge:
                                Console.ForegroundColor = ConsoleColor.DarkMagenta;
                                break;
                            case RegularCandies.LemonDrop:
                                Console.ForegroundColor = ConsoleColor.Yellow;
                                break;
                            case RegularCandies.GumSquare:
                                Console.ForegroundColor = ConsoleColor.Green;
                                break;
                            case RegularCandies.LollipopHead:
                                Console.ForegroundColor = ConsoleColor.Blue;
                                break;
                            case RegularCandies.JujebeCluster:
                                Console.ForegroundColor = ConsoleColor.White;
                                break;

                        }
                        Console.Write("{0,2}", "#");
                        Console.ResetColor();
                    }
                    Console.WriteLine();

                }

            }
            bool ScoreRowPresent(RegularCandies[,] playingField)
            {
                for (int row = 0; row < playingField.GetLength(0); row++)
                {

                    int count = 1;

                    for (int col = 1; col < playingField.GetLength(1); col++)
                    {
                        RegularCandies currCandies = playingField[row, col];
                        RegularCandies NextCandies = playingField[row, col - 1];
                        if (currCandies == NextCandies)
                        {
                            count++;
                            if (count >= 3)
                            {
                                Console.WriteLine("Row score!");
                                return true;
                            }

                        }
                        else
                        {
                            count = 1;
                        }
                    }
                }
                Console.WriteLine("No row score! :((");
                return false;
            }
            bool ScoreColumnPresent(RegularCandies[,] playingField)
            {

                for (int col = 0; col < playingField.GetLength(0); col++)
                {

                    int count = 1;

                    for (int row = 1; row < playingField.GetLength(1); row++)
                    {
                        RegularCandies currCandies = playingField[row, col];
                        RegularCandies NextCandies = playingField[row - 1, col];
                        if (currCandies == NextCandies)
                        {
                            count++;
                            if (count >= 3)
                            {
                                Console.WriteLine("Column score! :)");
                                return true;
                            }

                        }
                        else
                        {
                            count = 1;
                        }
                    }

                }
                Console.WriteLine("No Column score!! :(");
                return false;
            }
            void WritePlayingField(RegularCandies[,] playingField, string filename)
            {
                StreamWriter writer = new StreamWriter(filename);
                writer.WriteLine(playingField.GetLength(0).ToString());
                writer.WriteLine(playingField.GetLength(1).ToString());



                for (int row = 0; row < playingField.GetLength(0); row++)
                {
                    for (int col = 0; col < playingField.GetLength(1); col++)
                    {
                        int tem = (int)playingField[row, col];
                        writer.Write(tem);
                        writer.Write(" ");
                        if (col == playingField.GetLength(1) - 1)
                        {
                            writer.WriteLine();
                        }
                    }

                }
                writer.Close();
            }

            void DisplayScore(bool row, bool colomn)
            {
                if (row)
                    Console.WriteLine("row score!");
                else
                    Console.WriteLine("no row score!");
                if (colomn)
                    Console.WriteLine("colomn score!");
                else
                    Console.WriteLine("no colomn score!");
            }
            void WritePlayingFieldConsole(RegularCandies[,] playingField)
            {

                Console.WriteLine(playingField.GetLength(0).ToString());
                Console.WriteLine(playingField.GetLength(1).ToString());



                for (int row = 0; row < playingField.GetLength(0); row++)
                {
                    for (int col = 0; col < playingField.GetLength(1); col++)
                    {
                        int tem = (int)playingField[row, col];
                        Console.Write(tem);
                        Console.Write(" ");
                        if (col == playingField.GetLength(1) - 1)
                        {
                            Console.WriteLine();
                        }
                    }

                }
            }
            RegularCandies[,] ReadPlayingField(string filename)
            {
                RegularCandies[,] playingField2 = new RegularCandies[rowsz, colsz];
                StreamReader reader = new StreamReader(filename);
                int cols = int.Parse(reader.ReadLine());
                int rows = int.Parse(reader.ReadLine());
           
                while (!reader.EndOfStream)
                {
                    for (int row = 0; row < playingField2.GetLength(0); row++)
                    {
                        string[] temp = reader.ReadLine().Split(' ');

                        for (int colomn = 0; colomn < playingField2.GetLength(1); colomn++)
                        {
                            int value = int.Parse(temp[colomn]);
                            playingField2[row, colomn] = (RegularCandies)value;
                        }
                    }
                }
                return playingField2;

            }


        }
    }
}