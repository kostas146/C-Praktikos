﻿
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Ass2;

namespace Ass2
{
    public class HangmanGame
    {
        public string secretWord;
        public string guessedWord;
        public void Init(string secretWord)
        {
            this.secretWord = secretWord;
            guessedWord = new string('.', secretWord.Length);
        }
        public bool GuessLetter(char letter)
        {
            bool contains = secretWord.Contains(letter);
            if (contains)
            {
                char[] guessedWordLetters = guessedWord.ToCharArray();
                for (int i = 0; i < secretWord.Length; i++)
                {
                    if (secretWord[i] == letter)
                    {
                        guessedWordLetters[i] = letter;
                    }
                }
                guessedWord = new string(guessedWordLetters);
            }
            return contains;
        }
        public bool IsGuessed()
        {
            return (guessedWord == secretWord);
        }
    }
}