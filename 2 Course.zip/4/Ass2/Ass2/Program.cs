﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Ass2;

namespace Ass2
{
    class Program
    {
        static void Main(string[] args)
        {
            Program myProgram = new Program();
            myProgram.Start();
        }
        void Start()
        {
            
            List<string> words = ListOfWords(); // gets words
          
           string selectedWord = SelectWord(words); // selects word

            Console.WriteLine("Word randomlly picked from the list  is : "+ selectedWord);
            HangmanGame hangman = new HangmanGame();
            hangman.Init(selectedWord);
            DisplayWord(hangman.guessedWord);
            Console.WriteLine("");
            bool guessed = PlayHangman(hangman);
            if (guessed)
            {
                Console.WriteLine("You guessed the word!");
            }
            else
            {
                Console.WriteLine("You didn't guess the word, the word was {0}.", hangman.secretWord);
            }
        }
        List<string> ListOfWords()
        {
            List<string> words = new List<string>();

           
          
                string filename = "C:/Users/kosta/Desktop/UNIVERSITY/Programming/Programming 2/4/Ass2/Ass2/word.txt";
                StreamReader reader = new StreamReader(filename);

            while(!reader.EndOfStream)
            {
                string reading = reader.ReadLine();
                words.Add(reading);

            }
          
            return words;
        }
        string SelectWord(List<string> words)
        {
            
            Random rnd = new Random();
            int index = rnd.Next(words.Count);

            string selectedWord = words[index];
            

            return selectedWord;
        }
        bool PlayHangman(Ass2.HangmanGame hangman)
        {
            List<char> enteredLetters = new List<char>();
            int attempts = 8;
            while (!hangman.IsGuessed() && attempts > 0)
            {
                char letter = ReadLetter(enteredLetters);
                enteredLetters.Add(letter);
                Console.Write("Entered letters: ");
                DisplayLetters(enteredLetters);
                bool guessed = hangman.GuessLetter(letter);
                if (!guessed)
                {
                    attempts--;
                }
                Console.WriteLine("Attempts left: {0}\n", attempts);
                DisplayWord(hangman.guessedWord);
                Console.WriteLine("");
            }
            return hangman.IsGuessed();
        }
        void DisplayWord(string word)
        {
            char[] letters = word.ToCharArray();
            DisplayLetters(new List<char>(letters));
        }
        void DisplayLetters(List<char> letters)
        {
            string seperatedWord = string.Join(" ", letters);
            Console.WriteLine(seperatedWord);
        }
        char ReadLetter(List<char> blacklistLetters)
        {
            char letter;
            while (true)
            {
                Console.Write("Enter a letter: ");
                letter = Console.ReadLine()[0];
                if (blacklistLetters.Contains(letter))
                {
                    Console.WriteLine("You've already entered this letter!");
                }
                else
                {
                    break;
                }
            }
            return letter;
        }
    }
}