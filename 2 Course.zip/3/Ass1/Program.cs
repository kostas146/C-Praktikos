﻿using System;
using System.Collections.Generic;

namespace Ass1
{
    class Program
    {
        static void Main(string[] args)
        {
            Program myProgram = new Program();
           
            myProgram.Start();
        }


        void Start()
        {
           
            List<Course> report;
            report = ReadReport(3);
            
           
            DisplayReport(report);
            Console.ReadKey();
        }

        List<Course> ReadReport(int nrOfCourses)
        {
            List<Course> courses = new List<Course>();

            for (int i = 0; i < nrOfCourses; i++)
            {
                Console.WriteLine();
                Course course = ReadCourse("Enter course");
                courses.Add(course);
            }
            return courses;
        }

        void DisplayReport(List<Course> report)
        {
            int retakes = 0;
            bool passed = true;
            bool cumLaude = true;
            Console.WriteLine(" ");
            foreach (Course course in report)
            {
                DisplayCourse(course);
                DisplayPracticalGrade(course.practical);
             
                Console.WriteLine("");
                if (!course.Passed())
                {
                    passed = false;

                    retakes++;
                }
                if (cumLaude && !course.CumLaude())
                {
                    cumLaude = false;
                }
            }
            if (passed)
            {
                if (cumLaude)
                {
                    Console.WriteLine("You graduated Cum Laude!");
                }
                else
                {
                    Console.WriteLine("You graduated, congratulations!");
                }
            }
            else
            {
                Console.WriteLine("Too bad, you did not graduate, you got {0} retakes.", retakes);
            }


        }

        PracticalGrade ReadPracticalGrade(string question)
        {


            foreach (PracticalGrade pGrade in Enum.GetValues(typeof(PracticalGrade))) // Reads from class data
            {
                Console.Write((int)pGrade + ". " + pGrade + "   "); // prints data with enum values
            }
            Console.WriteLine("");
            PracticalGrade practicalGrade = (PracticalGrade)ReadInt(question);
            return practicalGrade;

        }
        Course ReadCourse(string question)
        {
            Course course = new Course();
            Console.WriteLine(question);
            course.name = ReadString("Name of Course: ");
            course.grade = ReadInt(string.Format("Enter grade for {0}: ", course.name));
            course.practical = ReadPracticalGrade(string.Format("Practical grade for {0}: ", course.name));
            return course;
        }
        void DisplayCourse(Course course)
        {
            Console.Write("{0}: {1}", course.name.PadRight(15), course.grade.ToString().PadRight(5));
        }
        void DisplayPracticalGrade(PracticalGrade practical)
        {
            Console.Write(practical);
        }

        string ReadString(string question)
    {
        Console.Write(question);
        return Console.ReadLine();
    }
    int ReadInt(string question)
    {
        Console.Write(question);
        int number = int.Parse(Console.ReadLine());
        return number;
    }
    char Readchar(string question)
    {
        Console.Write(question);
        char letter = char.Parse(Console.ReadLine());
        return letter;
    }
    void nigga()
        {
            int numba = 2;
            Console.WriteLine(numba);
            Console.WriteLine((PracticalGrade)numba);
            Console.ReadKey();
        }
}   

}


