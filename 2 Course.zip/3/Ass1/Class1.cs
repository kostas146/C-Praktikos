﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ass1
{
    enum PracticalGrade { None = 0, Absent, Insufficient, Sufficient, Good };
    class Course
    {
        public string name;
        public int grade;
        public PracticalGrade practical;

        public bool Passed()
        {
            if (grade >= 55 && practical >= PracticalGrade.Sufficient)
            {
                return true;
            }
            return false;
        }
        public bool CumLaude()
        {
            if (grade >= 80 && practical >= PracticalGrade.Good)
            {
                return true;
            }
            return false;

        }
    }
}
    
