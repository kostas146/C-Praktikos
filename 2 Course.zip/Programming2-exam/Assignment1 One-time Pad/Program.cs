﻿using System;

namespace Assignment1_One_time_Pad
{
    class Program
    {
        const string ALPHABET = "ABCDEFGHIJKLMN ...?!";
        static void Main(string[] args)
        {
            Program my = new Program();
            my.Start();
        }
        void Start()
        {
            
            int length = 40;
           
            Console.WriteLine("enter the message: ");
           string message= Console.ReadLine();
            string key = CreateSecretKey(length); ;
           
            OneTimePad(message, key);
            Console.WriteLine("Encypted: "+ message);
        }
        string CreateSecretKey(int length)
        {
            string secret = "";
            Random rnd = new Random();
            int index = rnd.Next(ALPHABET.Length);
            for (int i=0;i<length;i++)
            {
                secret += ALPHABET[index];
            }
            return secret;
        }
        string OneTimePad(string message, string key)
        {
            string result = "";
            int index1;
            int index2;
            for (int i =0;i<ALPHABET.Length;i++)
            {
               index1 = ALPHABET.IndexOf(message[i]);
                index2 = ALPHABET.IndexOf(key[i]);
                result +=ALPHABET.Substring(index1,index2);
            }
           
            return result;
        }

    }
}
