﻿using System;
using System.IO;
using System.Collections.Generic;

namespace Assignment_3
{
    class Program
    {
        const string filename = "C:/Users/Lenovo/Desktop/UNIVERSITY/Programming/Exam/Assignment 3/top2000-2019.csv";
        static void Main(string[] args)
        {
            Program my = new Program();
            my.Start();
        }
        void Start()
        {
            List<Song> ReadSong = new List<Song>();

            ReadSongs(filename);
            DisplaySongs(ReadSong);
        }
            List<Song> ReadSongs(string filename)
            {
                List<Song> ReadSong = new List<Song>();
                if (!File.Exists(filename))
                    return ReadSong;
            
            StreamReader reader = new StreamReader(filename);
                while (!reader.EndOfStream)
                {
                int z = 0;
                string line = reader.ReadLine(); 
                string[] sentence = line.Split(';');
                Song blueprint = new Song();
                
                    blueprint.ranking = Convert.ToInt32(sentence[z]);

                    blueprint.title = (sentence[z]);
                    blueprint.artist = (sentence[z]);
                   blueprint.year = Convert.ToInt32((sentence[z]));
                    ReadSong.Add(blueprint);
                z++;
               
            }
           

            reader.Close();

            return ReadSong;
            }
           void DisplaySongs(List<Song> songs)
        {
            
            Console.Write(songs);
        }
        
        }

    }
