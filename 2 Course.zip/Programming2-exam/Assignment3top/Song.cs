﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment_3
{
    class Song
    {
        public int ranking;
        public string title;
        public string artist;
       public int year;
    }
}
