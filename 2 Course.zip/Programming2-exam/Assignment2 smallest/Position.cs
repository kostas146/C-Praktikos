﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment2
{
    public class Position
    {
        public int row;
        public int col;
        public int value;
    }
}
