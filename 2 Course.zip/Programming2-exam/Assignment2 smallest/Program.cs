﻿using System;
using System.Collections.Generic;

namespace Assignment2
{
    class Program
    {
        const int row = 15;
        const int col = 20;
        Position smallest = new Position();
        Position biggest = new Position();
        static void Main(string[] args)
        {
            Program my = new Program();
            my.start();
        }
        void start()
        {
            int[,] matrix = new int[row, col];
            FillMatrix(matrix);
            DisplayMatrix(matrix);

            string name = "smallest";
            string namee = "biggest";
            SearchBiggest(matrix);
            SearchSmallest(matrix);
            DisplayPosition(name, smallest);
            DisplayPosition(namee, biggest);

            DisplayMatrixPosition(matrix, biggest, smallest);

        }
        void FillMatrix(int[,] matrix)
        {

            Random rnd = new Random();

            for (int row = 0; row < matrix.GetLength(0); row++)
            {
                for (int col = 0; col < matrix.GetLength(1); col++)
                {
                    matrix[row, col] = rnd.Next(0, 201);
                }
            }
        }
        void DisplayMatrix(int[,] matrix)
        {
            for (int roww = 0; roww < matrix.GetLength(0); roww++)
            {
                Console.WriteLine();
                for (int coll = 0; coll < matrix.GetLength(1); coll++)
                {
                    Console.Write("{0,05} ", matrix[roww, coll]);
                }
            }
        }
        void DisplayPosition(string name, Position pos)
        {
            
        
            Console.WriteLine(name +" " + pos.value + " (row: " + pos.row + " column " + pos.col);

            
        }
    
    Position SearchSmallest(int[,] matrix)
    {
       
        smallest.value = matrix[0, 0];
        for (int roww = 0; roww < matrix.GetLength(0); roww++)
        {
            for (int coll = 0; coll < matrix.GetLength(1); coll++)
            {
                
                    if (matrix[roww, coll] < smallest.value)
                    {
                        smallest.value = matrix[roww, coll];
                        smallest.row = roww + 1;
                        smallest.col= coll + 1;
                    }
                   
                
            }
        }
        return smallest;
    }

   Position SearchBiggest(int[,] matrix)
    {
       
        biggest.value = matrix[0, 0];
        for (int roww = 0; roww < matrix.GetLength(0); roww++)
        {
            for (int coll = 0; coll < matrix.GetLength(1); coll++)
            {
                
                    if (matrix[roww, coll]> biggest.value)
                    {
                    biggest.value = matrix[roww, coll];
                        biggest.row = roww + 1;
                        biggest.col = coll + 1;
                    }

            }
        }
        return biggest;
    }
    void DisplayMatrixPosition(int[,] matrix, Position biggest, Position smallest)
    {
            for (int roww = 0; roww < matrix.GetLength(0); roww++)
            {
                Console.WriteLine();
                for (int coll = 0; coll < matrix.GetLength(1); coll++)
                {
                    Console.Write("{0,5} ", matrix[roww, coll]);
                  

                }
            }

        }

}
}

