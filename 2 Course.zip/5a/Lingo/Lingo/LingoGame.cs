﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using MyToools;

namespace Lingo
{
    class LingoGame
    {
        public string playerWord;
        public string lingoWord;
        public StateOfLetter[] letters = { StateOfLetter.Correct, StateOfLetter.WrongPos, StateOfLetter.Incorrect };
       
        
        public void InitLingo(string something)
        {
            this.lingoWord = something;
        }
        public bool isGuessed(LingoGame game, string playerword)
        {

            bool isguessed;

            if (game.lingoWord == playerword)
            {
                isguessed = true;
            }

            else
            {

                isguessed = false;
            }

            return isguessed;
        }
    }
}
    

