﻿using System;
using MyTools;
namespace MyTools_App
{
    public class Program
    {
        static void Main()
        {
            Program myProgram = new Program();
            myProgram.Start();
        }
        
       public void Start()
        {
            int value = Class1.ReadInt("Enter a value: ",0);
            Console.WriteLine("You entered {0}.", value);

            int age = Class1.ReadInt2("How old are you? ", 0, 120);
            Console.WriteLine("You are {0} years old.", age);

            string name = Class1.ReadString("What is your name? ");
            Console.WriteLine("Nice meeting you {0}.", name);
           
        }
    }
}
