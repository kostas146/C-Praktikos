﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyTools
{
    public class Class1
    {
        public static int ReadInt(string question, int value)
        {
            
            Console.Write(question);
            int number = int.Parse(Console.ReadLine());
                return number;
        }
       
        public static int ReadInt2(string question, int min, int max)
        {
            Console.Write(question);
            int number = int.Parse(Console.ReadLine());
            if (number <= max && number >= min)
                return number;
            else
                return ReadInt2(question, min, max);
        }
            public static string ReadString(string question)
        {
            Console.Write(question);
            
            return Console.ReadLine();
        }
    }
}
