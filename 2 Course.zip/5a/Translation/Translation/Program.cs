﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Translation
{
    class Program
    {
        static void Main(string[] args)
        {
            Program myProgram = new Program();
            myProgram.Start();
        }
        void Start()
        {
            string filename = "C:/Users/kosta/Desktop/UNIVERSITY/Programming/Programming 2/5a/Translation/dictionary.csv";
           // ReadWords(filename);
           
            TranslateWords(ReadWords(filename));

            Console.ReadKey();

        }
        Dictionary<string, string> ReadWords(string filename)

        {
            Dictionary<string, string> Words = new Dictionary<string, string>();

            StreamReader reader = new StreamReader(filename);
            while (!reader.EndOfStream)
            {
                string line = reader.ReadLine();

                string[] words = line.Split(';');

                string dutch = words[0];
                string english = words[1];

                Words.Add(dutch, english);
            }


            return Words;
        }
           
          
        
        void TranslateWords(Dictionary<string, string> words)
        {
            Console.Write("Enter a word : ");
            string user = Console.ReadLine();

            while (user != "stop" && user != "listall")
            {
                if (words.ContainsKey(user))
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine(user + " => " + words[user]);
                    Console.ResetColor();
                }
                else
                {
                    Console.WriteLine("word '{0}' not found", user);
                }
                Console.Write("Enter a word : ");
                user = Console.ReadLine();
            }

            if (user == "list all")
                ListAllWords(words);


           if (user == "stop")
            Console.WriteLine("End of the program.");
        }

        void ListAllWords(Dictionary<string, string> words)
        {
            
            Console.ForegroundColor = ConsoleColor.Yellow;

            foreach (KeyValuePair<string, string> l in words)
                Console.WriteLine("{0} => {1}", l.Key, l.Value);

            Console.ResetColor();
            Console.WriteLine("LISTED ALL WORDS");
        }
    }
}

  