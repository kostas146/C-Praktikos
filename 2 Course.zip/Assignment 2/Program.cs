﻿using System;

namespace Assignment_2
{
   

        public class Position
        {
            public int row=0;
            public int column=0;
        }

    class Program
    {
        


        static void Main(string[] args)
        {
            Program myprogram = new Program();
            
            int[,] matrix = new int[8, 8];
            int min = 0;
            int max = 100;
            Position loc = new Position();

            myprogram.InitMatrixRandom(matrix,min,max);
            Console.WriteLine("Enter THE number");
            int number = int.Parse(Console.ReadLine());
            myprogram.SearchNumber(matrix, number, loc);
            myprogram.print(loc,number);
        }
        void InitMatrixRandom(int[,] matrix, int min, int max)
        {
            Random randNum = new Random();
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                   
                    matrix[i, j] = randNum.Next(min, max);
                    Console.Write(string.Format("{0,5}", matrix[i, j] + " "));

                }
                Console.WriteLine();
            }
        }
       void print (Position loc, int n)

        {
            Console.WriteLine("Number " + n + " is found at position ["+loc.row+"] " + " [" + loc.column+"]");
        }

        // SEARCH
        Position SearchNumber(int[,] matrix, int number, Position loc)
        {

            
            for (int x = 0; x <= 8; x++)
            {
                if (number==matrix[x,0]
                {
                    loc.row++;
                }
                else if (matrix[x,0]== number)
                { break; }
               
                for (int y = 0; y <= 8; y++)
                {
                   
                    if (matrix[0, y] != number)
                    {
                        loc.column++;
                        
                    }
                    else if (matrix[x, 0] == number)
                    { break;}
                    
                }
            }
            return loc;
        }

    }

    }

//kill me 