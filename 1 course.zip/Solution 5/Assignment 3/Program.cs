﻿using System;

namespace Assignment_3
{
    class Program
    {
        
        static void Main(string[] args)
        {
            int number = 1;
            
            while (number != 0)
            {
                Console.WriteLine("Enter year (0 is stop value):");
                number = int.Parse(Console.ReadLine());

               
                if (leap(number) == true)
                    Console.WriteLine(number + "  is a leap number");
                else
                    Console.WriteLine(number + "   is not a leap number");

            }

            static Boolean leap(int number1)
            {
                if (DateTime.IsLeapYear (number1))
                     { return true; }
                else { return false; }
               
                
            }
        }
    }
}
