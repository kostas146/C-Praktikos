﻿using System;

namespace Assignment_2
{
    class Program
    {
        static void Main(string[] args)
        {
           
            int number = 1;

            while ( number != 0)
            {
                Console.WriteLine("Enter number (0 is stop value) : ");
                number = int.Parse(Console.ReadLine());

                int k = 0;
                for (int i = 1; i <= number; i++)
                {
                    if (number % i == 0)
                    {
                        k++;
                    }
                }
                if (k == 2)
                {
                    Console.WriteLine("Entered Number is a Prime Number ");
                }
                else
                {
                    Console.WriteLine("Not a Prime Number");
                }
               
            }
        }
    }
} 