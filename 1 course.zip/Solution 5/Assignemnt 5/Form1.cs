﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignemnt_5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int first = int.Parse(textBox1.Text);
            int second = int.Parse(textBox2.Text);
            double sum = SUM(first, second);
            label4.Text = sum.ToString("N2") ;
        }


        private void button2_Click(object sender, EventArgs e)
        {
            int first = int.Parse(textBox1.Text);
            int second = int.Parse(textBox2.Text);
            double sub = SUB(first, second);
            label4.Text = sub.ToString("N2");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int first = int.Parse(textBox1.Text);
            int second = int.Parse(textBox2.Text);
            double mult = MULT(first, second);
            label4.Text = mult.ToString("N2");
        }

        private void button4_Click(object sender, EventArgs e)
        { 
            int first = int.Parse(textBox1.Text);
            int second = int.Parse(textBox2.Text);
            double dev = DEVI(first, second);
            label4.Text = dev.ToString("N2");
          


        }

        static int SUM(int f, int s)
        {
            int result = f + s;
            return result;
        }
        static int SUB(int f, int s)
        {
            int result = f - s;
            return result;
        }
        static int MULT(int f, int s)
        {
            int result = f * s;
            return result;
        }
        static int DEVI(int f, int s)
        {


            int result = f / s;
           
                return result;
            

          
        }
    }
    }

