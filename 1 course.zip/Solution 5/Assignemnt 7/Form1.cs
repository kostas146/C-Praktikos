﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assigment_7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double converted = 0;
            int degree = int.Parse(textBox1.Text);
            if (radioButton1.Checked)
            {
                Celsius2Kelvin(degree, out converted);
                label3.Text = converted.ToString("N2");
            }
            if (radioButton2.Checked)
            {
                Celsius2Fahrenheit(degree, out converted);
                label3.Text = converted.ToString("N2");
            }
            if (radioButton3.Checked)
            {
                Fahrenheit2Celsius(degree, out converted);
                label3.Text = converted.ToString("N2");
            }

        }
        static void Celsius2Kelvin(int degreee, out double resultt)
        {
            resultt = degreee + 273;
        }
        static void Celsius2Fahrenheit(int degreee, out double resultt)
        {
            resultt = degreee * 1.8 + 32;
        }
        static void Fahrenheit2Celsius(int degreee, out double resultt)
        {
            resultt = (degreee - 32) * 5/9;
        }
    }
}
