﻿using System;

namespace Assignment_4
{
    class Program
    {

        static void Main(string[] args)
        {
            int[] count = new int[3];


            Console.WriteLine("Enter a text>");
            string text = Console.ReadLine();
            SearchText(text, count);
            Console.Write("Result :" + count[0].ToString() + " Full stops   " + count[1].ToString() + " Commas  "+ count[2].ToString() + " Semicolons ");
            
           
        }



        public static void SearchText(string textt, int[] coun)
        {
            foreach (char c in textt)
            {
                if (c == '.')
                {
                    coun[0] += 1;
                }
                if (c == ',')
                {
                    coun[1] += 1;
                }
                if (c == ';')
                {
                   coun[2] += 1;
                }
                    
             }
            }

        }
    }

