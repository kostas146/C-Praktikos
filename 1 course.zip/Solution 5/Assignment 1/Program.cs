﻿using System;

namespace Assignment_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a price: ");
            double price = int.Parse(Console.ReadLine());
            double product = VAT(price);
            Console.WriteLine("Price: " + price + "  VAT: " + product +"   ToTal: "+(product+price));
          
        }

        static double VAT(double n)
        {

            double tax = n * 0.21;
            return tax;

        }
    }
}
