﻿using System;

namespace Assignment_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter course name :");
            string course = Console.ReadLine();

            Console.Write("Enter number of students : \n");
            string input = Console.ReadLine();
            int nmbstudent = int.Parse(input);

            string[] names = new string[nmbstudent];
            int[] grades = new int[nmbstudent];

            int sum = 0;
            double average = 0;

            int highest = grades[0];
            string highestName = names[0];
            for (int i = 1; i <= nmbstudent; i++)
            {
                Console.Write("Enter name of student {0} : ", i);
                names[i - 1] = Console.ReadLine();
            }
            for (int z = 0; z < nmbstudent; z++)
            {
                Console.Write("Enter grade of  " + names[z] + " : ");
                grades[z] = int.Parse(Console.ReadLine());
                sum += grades[z];
                if (grades[z] > highest)
                {
                    highest = grades[z];
                    highestName = names[z];

                }
                average = sum / nmbstudent;
            }
            Console.WriteLine("Average " + average.ToString());
            if (highest == 10)
            { Console.Write("Best score of all students - " + highestName + " with a maximum grade " + highest); }
            else
                Console.WriteLine("Best score of all students - " + highestName + " with  " + highest);


            for (int k = 0; k < nmbstudent; k++)
            {
                Console.WriteLine("Grade for student " + names[k] + " (Course " + course + ") is: " +grades[k]);
            }
        }
       
    }
}
