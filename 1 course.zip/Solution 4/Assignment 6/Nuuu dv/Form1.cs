﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Nuuu_dv
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();

        }

        public int[] BOX = new int[20];

        Random Rnumber = new Random();


        private void button1_Click(object sender, EventArgs e)
        {
            string input = textBox1.Text;
            int number = int.Parse(input);
            for (int i = 0; i < BOX.Length; i++)
            {
                if (number < BOX[i])
                { BOX[i] += 10; }
                else
                { BOX[i] -= 5; }
                label4.Text += "Element" + i + " = " + BOX[i] + "\n";

            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
            for (int i = 0; i < BOX.Length; i++)
            {
                BOX[i] = Rnumber.Next(0, 500);
                label3.Text += "Element" + i + " = " + BOX[i] + "\n";
               
            }
            
        }
    }
}