﻿using System;

namespace Assignement_1
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] BOX = new int[20];

            int min = 0;
            int max = 200;
            int average = 0;
            int sum = 0;
            int diff = 0;
            Random Rnumber = new Random();
            for (int i=0;i<BOX.Length;i++)
            {
                BOX[i] = Rnumber.Next(min, max);
               
                Console.WriteLine("Element "+ i + " is  " + BOX[i] );
                sum += BOX[i];
                
            }
            average = sum / BOX.Length;
            Console.WriteLine("Average is " + average);
            for (int z =0;z<BOX.Length;z++)
            {
                if (BOX[z] > average)
                { diff = BOX[z] - average; }
                else
                { diff = average - BOX[z]; }


                Console.WriteLine("Diff between average and element " + z + " is " + diff);
            }
            
        }
    }
}
