﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment_7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] dice = new int[6000];
            for (int i = 0; i < dice.Length; i++)
            { dice[i] = 0; }
            Random number = new Random();
            int[] burger = new int[6];
            int p = 1;
            for (int z = 0; z < 6000; z++)
            {
                for (int q = 0; q < 6; q++)
                {
                    dice[q] = number.Next(1, 7);
                }
                if (dice[0] == 1)
                { burger[0] += 1; }
                if (dice[1] == 2)
                { burger[1] += 1; }
                if (dice[2] == 3)
                { burger[2] += 1; }
                if (dice[3] == 4)
                { burger[3] += 1; }
                if (dice[4] == 5)
                { burger[4] += 1; }
                if (dice[5] == 6)
                { burger[5] += 1; }
            }
           
            for (int k = 0; k < burger.Length; k++)
            {    
                label1.Text += "Number of throws of value " + p + "= "+ burger[k] + "\n";
                p+=1;
            }
        }
    }
}
