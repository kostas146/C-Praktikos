﻿using System;

namespace help
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] array = new int[20]; // This is how u create a new array 20* means how many positions this array will have [from 0 to 19]
            int i = 0;

            Console.WriteLine("Enter in numbers (1-20) enter 0 when finished:");
            Console.WriteLine("Please enter a number:");
            array[i] = int.Parse(Console.ReadLine()); // your array is already fixed to be int , you cannot simply convert it to string.
                                                      // user enters first number 

            while (array[i] != 0) // != means not equal.
            {
                Console.WriteLine("Enter DAt NUMBA(0=stop) :"); // code for every  other "enter that number" etc.
                i++;
                array[i] = int.Parse(Console.ReadLine()); // puts every number in the array . 
                // If u noticed its the same commands just in the loop. I didint manage to do it one loop, bcuz im lazy, as long it works it okeeh

            }

            Console.Write("Enter a searchvalue: ");


        }
        }
}
