﻿using System;

namespace Assignment_4
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 0;
            int[] numbers = new int[20];
            Console.WriteLine("Enter DAt NUMBA:");
            numbers[i] = int.Parse(Console.ReadLine());


            while (numbers[i] != 0)
            {
                Console.WriteLine("Enter DAt NUMBA(0=stop) :");
                i++;
                numbers[i] = int.Parse(Console.ReadLine());
            }
            Console.Write("Enter a searchvalue: ");
            int Sphagetti = int.Parse(Console.ReadLine());
            int occurence = 0;
            for (int z = 0; z < numbers.Length; z++)
            {
                if (numbers[z] == Sphagetti)
                {
                    occurence++;
                }
            }
            Console.Write("Number of occurences of searchvalue " + Sphagetti + " is:" + occurence);
        }
    }
}
