﻿using System;
namespace Assignment_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] position = new int[20];
            Random number = new Random();

            int SPAGGETIPASTAMAKARONYYEEEEE = 0;

            for (int i = 0; i < position.Length; i++)
            {
                position[i] = number.Next(0, 150);
                Console.WriteLine("Element " + i + " = " + position[i]); ;

            }
            int min = position[0];
            int k = 0;
            for (int z= 1; z<position.Length;z++)
            {
                if (position[z] < min)
                {
                    min = position[z];

                }
                if (position[k]==position[z])
                {
                    k++;
                    SPAGGETIPASTAMAKARONYYEEEEE++; }

            }
            Console.WriteLine("Smallest number = " + min);
            Console.WriteLine("Occurence = " + SPAGGETIPASTAMAKARONYYEEEEE);
        }
    }
}
    

