﻿using System;

namespace Assignment_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a word: ");
            string word = Console.ReadLine();
            char[] letters = word.ToCharArray();
            Array.Reverse(letters);

            string secondword = new string(letters);
            
                if (secondword == word)
                { Console.Write(word + "  is a palindrome. "); }
                else
                { Console.Write(word + " is not a palindrome."); }
            
            
        }
    }
}
