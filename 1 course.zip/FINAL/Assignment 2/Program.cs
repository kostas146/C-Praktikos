﻿using System;

namespace Assignment_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int number=1;
            while (number != 0 || number > 0)
            {
                Console.WriteLine('\n'+"Enter a number plss!: ");
                number = int.Parse(Console.ReadLine());
                string[] BLOCK = new string[number];
                for (int i = 0; i < number / 2; i++)
                {

                    BLOCK[i] += "*";


                }
                for (int z = number / 2; z < number; z++)
                {

                    BLOCK[z] += "!";

                }
                for (int a = 0; a < number; a++)
                {
                    Console.Write(BLOCK[a]);
            } }
           
        }
    }
}
