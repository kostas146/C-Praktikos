﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment_7
{
    
    public partial class Form1 : Form
    {
        const double VATconst = 0.21;
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = " ";
            textBox2.Text = " ";
            textBox3.Text = " ";
            label7.Text = " ";
            label8.Text = " ";
            label9.Text = " ";


        }

        private void Button2_Click(object sender, EventArgs e)
        {
            string input = textBox1.Text;
            double Start = double.Parse(input);
            string input1 = textBox2.Text;
            double End = double.Parse(input1);
            string input2 = textBox3.Text;
            double KmH = double.Parse(input2);

            double exclVAT = (End - Start) * KmH;
            label7.Text = exclVAT.ToString();

           

            double inclVAT = (exclVAT * VATconst) + exclVAT;
            label9.Text = inclVAT.ToString();

            double VAT = inclVAT - exclVAT;
            label8.Text = VAT.ToString();


        }

        private void Label7_Click(object sender, EventArgs e)
        {

        }
    }
}
