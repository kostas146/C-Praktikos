﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        const double VAT = 0.21;
        static void Main(string[] args)
        {

            Console.WriteLine("Enter a price:");
            string input = Console.ReadLine();
            double price = double.Parse(input);
            

            double total = (price * VAT) + price;
            Console.WriteLine("price: " + price);  
            Console.WriteLine("VAT: " + VAT);
            Console.WriteLine("total: " + total);
        }
    }
}
