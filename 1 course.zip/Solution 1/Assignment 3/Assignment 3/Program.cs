﻿using System;

namespace Assignment_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter number of seconds : ");
            string SEC = Console.ReadLine();

            int seconds = int.Parse(SEC);

            
            int s = seconds % 60; // liekana    
            seconds /= 60; // i minutes
            int mins = seconds % 60;
            int hours = seconds / 60;

            Console.WriteLine(hours, " : ", mins, " : ", s);

            
        }
    }
}
