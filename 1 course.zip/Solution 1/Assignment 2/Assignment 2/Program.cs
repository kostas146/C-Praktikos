﻿using System;

namespace Assignment_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter 1st number: ");
            string firstNB = Console.ReadLine();
            Console.WriteLine("Enter 2st number: ");
            string secondNB = Console.ReadLine();
            Console.WriteLine("Enter 3st number: ");
            string thirdNB = Console.ReadLine();
                double FirstNb = double.Parse(firstNB);
               double secondNb = double.Parse(secondNB);
                double thirdNb = double.Parse(thirdNB);
            double avarage = (FirstNb + secondNb + thirdNb) /3;
   
            Console.WriteLine("The average is: "+ avarage);
        }
    }
}
