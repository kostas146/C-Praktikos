﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment_6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            string input = textBox1.Text;
            double seconds = double.Parse(input);
            double remain = seconds % 60; // remain

            seconds /= 60; //  1 foot back

            double minutes = seconds % 60;

            double hours = seconds / 60;
            label3.Text = hours.ToString("N0"); label4.Text = minutes.ToString("N0"); label5.Text = remain.ToString("N0");
        }
    }
}
