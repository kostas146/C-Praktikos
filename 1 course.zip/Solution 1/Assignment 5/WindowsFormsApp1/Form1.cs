﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
          
            string input0 = textBox1.Text;
            double Number0 = double.Parse(input0);

            string input1 = textBox2.Text;
            double Number1 = double.Parse(input1);

            string input2 = textBox3.Text;
            double Number2 = double.Parse(input2);

            double avarage = (Number0 + Number1 + Number2) / 3;
            label5.Text = avarage.ToString();
        }
    }
}
