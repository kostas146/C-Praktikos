﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment_8
{
    public partial class Form1 : Form
    {
        const double Jeansprice = 100;
        const double Tshirtsprice = 30;
        const double VATprice = 0.21;
        public Form1()
        {
            InitializeComponent();
        }

        private void GroupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void Label8_Click(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {

            string input = textBox1.Text;
            double Tshirts = double.Parse(input);

            string input1 = textBox2.Text;
            double Jeans = double.Parse(input1);

            label7.Text = DateTime.Now.Date.ToShortDateString();
            label11.Text = DateTime.Now.ToString("h:mm:ss tt");

            double price = (Tshirts * Tshirtsprice) + (Jeans * Jeansprice);
            double VAT = ((Tshirts * Tshirtsprice) * VATprice) + ((Jeans * Jeansprice) * VATprice);
            label8.Text = price.ToString();
            label9.Text = VAT.ToString();
            double total = price + VAT;
            label10.Text = total.ToString();
        }


            private void Label7_Click(object sender, EventArgs e)
        {
            
        }
    }
}
