﻿using System;

namespace Assignment_5
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Enter a year: ");
            int year = int.Parse(Console.ReadLine());
            if(year<0)
            { Console.Write("Year must be positive!"); }
            while (year != 0)
            {
          
                if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0 )
                       
                {
                    Console.WriteLine(year + " is a leap year");
                }
                else if(year < 0)
                {  
                    Console.WriteLine("Year must be positive!");
                }

                else
                {
                    Console.WriteLine(year + " is a not a leap year");
                }
                Console.WriteLine("Enter a year: ");
                year = int.Parse(Console.ReadLine());
              

            }
        }
    }
}
