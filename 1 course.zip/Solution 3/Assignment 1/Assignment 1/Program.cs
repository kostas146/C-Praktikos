﻿using System;

namespace Assignment_1
{
    class Program
    {
        static void Main(string[] args)
        {

            
            Console.WriteLine("Enter a number:");
            int number = int.Parse(Console.ReadLine());
            
            double positive=0;
            while (number != 0)
            {
                if (number >= 1)
                    positive += number;

                Console.WriteLine("Enter a number:");
                  number = int.Parse(Console.ReadLine());
                
                
            }
            Console.WriteLine("average of all positive number is : " + positive);

        }
    }
}
