﻿using System;

namespace Assignment_3
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Enter the number:");
            int number = int.Parse(Console.ReadLine());
            int NumberRW = 0;
            int sum = 0;
            while (number != 0)
            {
                NumberRW++;
               if (number > 0 && NumberRW % 5 == 0)
                { sum += number; }
                Console.WriteLine("Enter the number:");
                 number = int.Parse(Console.ReadLine());

            }
            Console.WriteLine("Sum of 5th , 10th, 15th ... number is :"+sum);
            }
    }
}
