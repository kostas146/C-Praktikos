﻿using System;

namespace Assignment_2
{
    class Program
    {
      
        static void Main(string[] args)
        {


            Console.WriteLine("Enter the TARGET number: ");
            int valid = int.Parse(Console.ReadLine());
            int number=1;
            int equal = 0;
            while (number != 0)
            {
                Console.WriteLine("Enter the number: ");
                number = int.Parse(Console.ReadLine());
                if (valid==number)
                { equal++; }
            }
            Console.WriteLine("count of numbers equal:" + equal);
        }
    }
}
