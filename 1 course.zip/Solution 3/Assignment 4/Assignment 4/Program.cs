﻿using System;

namespace Assignment_4
{
    class Program
    {
        static void Main(string[] args)
        {
            int first = 0;
            int second = 1;
            int count = 0;
            Console.WriteLine(first + " " + second + " "); 
            for (int i = 0; i < 19; i++)
            {
                count = first + second;
                Console.Write(count + " ");
                first = second; 
                second = count;
                
                    
            }
            
        } 

            
        }
                
            }
        
    
