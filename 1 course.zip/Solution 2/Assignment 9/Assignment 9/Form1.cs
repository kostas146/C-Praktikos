﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment_9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            string input = textBox2.Text;
            double age = double.Parse(input);
            string input0 = textBox1.Text;
            double duration = double.Parse(input0);
            double fee = 0;

            if (radioButton1.Checked)
            { fee += 175; }
            if (radioButton2.Checked)
            { fee += 225; }
            if (age > 40)
            { fee = fee - 25; }
            if (duration > 10)
            { fee -= 20; }

            label5.Text = fee.ToString() +"Eu.";

            
        }
    }
}
