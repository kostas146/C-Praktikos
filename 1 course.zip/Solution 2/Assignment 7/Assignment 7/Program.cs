﻿using System;

namespace Assignment_7
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter weight (kg) :");
            string input = Console.ReadLine();
            double weight = double.Parse(input);
            Console.WriteLine("Enter length (cm) :");
            string input1 = Console.ReadLine();
            double length = double.Parse(input1);
            Console.WriteLine("Enter gener (male/female) :");
            string input2 = Console.ReadLine();
            string gender = input2;
            

            

            double bmi = weight / ((length/100)*(length / 100));
            if (gender == "male")
            {
                double Mhealthy1 = (20 * (length / 100) * (length / 100));
                double Mhealthy2 = (25 * (length / 100) * (length / 100));
                Console.WriteLine("bmi-value = " + bmi.ToString("0.0"));
                Console.WriteLine("Normal bmi-values (min .. max): 20 .. 25");
                Console.WriteLine("Healthy weight range :" + Mhealthy1.ToString("N1") + "..." + Mhealthy2.ToString("N1")) ; ;
            }


            else if (gender == "female")
            {
                double Whealthy1 = (19 * (length / 100) * (length / 100));
                double Whealthy2 = (24 * (length / 100) * (length / 100));
                Console.WriteLine("bmi-value = " + bmi);
                Console.WriteLine("Normal bmi-values (min .. max): 19 .. 24");
                Console.WriteLine("Healthy weight range :" + Whealthy1.ToString("N1") + "..." + Whealthy2.ToString("N1")); ;
            }


        }
        }
}
