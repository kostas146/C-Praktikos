﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment_14
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            //   kg/mkubu
            string input = textBox1.Text;
            double length = double.Parse(input);
            string input1 = textBox2.Text;
            double Weight = double.Parse(input1);

            double bmi = Weight / ((length / 100) * (length / 100));
            label6.Text = bmi.ToString("N1");
            label7.Text = "20...25";
            double MH1 = (20 * (length / 100) * (length / 100));
            double MH2 = (25 * (length / 100) * (length / 100));
            label8.Text = MH1.ToString("N1") + "..." + MH2.ToString("N1");
        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void Button2_Click(object sender, EventArgs e)
        {
            string input = textBox1.Text;
            double length = double.Parse(input);
            string input1 = textBox2.Text;
            double Weight = double.Parse(input1);

            double bmi = Weight / ((length / 100) * (length / 100));
            label6.Text = bmi.ToString("N1");
            label7.Text = "19...24";
            double WH1 = (19 * (length / 100) * (length / 100));
            double WH2 = (24 * (length / 100) * (length / 100));
            label8.Text = WH1.ToString("N1") + "..." + WH2.ToString("N1");

        }
        }
    }

