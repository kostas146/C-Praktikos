﻿using System;

namespace Assignment_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("ENTER THE NUMBER (1...4)");
            string input = Console.ReadLine();
            double number = double.Parse(input);

            switch (number)
            {
                case 1:
                    Console.WriteLine("CLUBS");
                    break;
                case 2:
                    Console.WriteLine("DIAMONDS");
                    break;
                case 3:
                    Console.WriteLine("HEARTS");
                    break;
                case 4:
                    Console.WriteLine("SPADES");
                    break;
            }
        }
    }
}
