﻿using System;

namespace Assignment_6
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter score: ");
            string input = Console.ReadLine();
            int score = int.Parse(input);


            if (score > 90)
            { Console.WriteLine("Grade : A /course passed"); }

            else if (score >= 80)
                Console.WriteLine("Grade : B /course passed");
            else if (score >= 70)
                Console.WriteLine("Grade : C /course passed");
            else if (score >= 60)
                Console.WriteLine("Grade : D /course passed");
            else if (score <= 59)
                Console.WriteLine("Grade : F /course not passed"); ;

            ;
        }
    }
}
