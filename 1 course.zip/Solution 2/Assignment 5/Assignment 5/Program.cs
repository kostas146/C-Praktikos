﻿using System;

namespace Assignment_5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter first number:");
            string input = Console.ReadLine();
            int first = int.Parse(input);

            Console.WriteLine("Enter second number:");
            string input0 = Console.ReadLine();
            int second = int.Parse(input0);

            if (first % second == 0)
            { Console.WriteLine("Number 1 is multiple of number 2"); }
            else if (second % first == 0)
            { Console.WriteLine("Number 2 is multiple of number 1 "); }
            else
                Console.WriteLine("Numbers are no multiples")
                       ;
        }
    }
}
