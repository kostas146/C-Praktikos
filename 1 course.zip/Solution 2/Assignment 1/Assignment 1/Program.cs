﻿using System;

namespace Assignment_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter first number:");

            int first = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter second number:");
 
            int second = int.Parse(Console.ReadLine());

           int higher;
            int lower;
            if (first > second)
            {
                 higher = first; lower = second; }
            else
            { higher = second; lower = first; }
      
            Console.WriteLine("Higher value is :"+ higher.ToString());

            Console.WriteLine("Lower value is:"+lower.ToString());


        }
    }
}
