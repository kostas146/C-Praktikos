﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment_133
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            string input = textBox1.Text;
            double days = double.Parse(input);
            string input11 = textBox2.Text;
            double km = double.Parse(input11);
            string input22 = textBox3.Text;
            double litres = double.Parse(input22);
            double rate = 55;
            double price = days*rate;
            double limit = days * 100;
            
            if (limit < km)
           { price += ((km-limit) * 0.25); }
            if (checkBox1.Checked)
            { price += ((litres) * 2.20); }
            

            label5.Text = price.ToString() ;

        }
    }
}
