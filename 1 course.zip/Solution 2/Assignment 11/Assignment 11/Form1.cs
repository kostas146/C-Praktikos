﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment_11
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            string input = textBox1.Text;
            double first = double.Parse(input);
            string input0 = textBox2.Text;
            double second = double.Parse(input0);

            double average = (first+second)/2;
            double diff = 0;

            if (first > second)
            {
                label6.Text = first.ToString();
                label7.Text = average.ToString();
                diff = first-average;
                label8.Text = diff.ToString();
            }
            if (first < second)
            {
                label6.Text = second.ToString();
                label7.Text = average.ToString();
                diff = second-average;
                label8.Text = diff.ToString();
            }

        }
    }
}
