﻿using System;

namespace Assignment_4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter first number:");
            string kebab = Console.ReadLine();
            double first = double.Parse(kebab);
            Console.WriteLine("Enter second number:");
            string chicken = Console.ReadLine();
            double second = double.Parse(chicken);
            Console.WriteLine("Enter third number:");
            string Trance = Console.ReadLine();
            double third = double.Parse(Trance);

            double sum = first + second + third;
            double aver = (first + second + third) / 3;
            double product = (first * second * third);
            Console.WriteLine("Sum = " + sum);
            Console.WriteLine("Average = " + aver);
            Console.WriteLine("Product = " + product);
            Console.WriteLine("Highest value: " + Math.Max(first, Math.Max(second, third)));
            Console.WriteLine("Lowest value: "+Math.Min(first, Math.Min(second, third))); 

                ;

            }
        }
    }
