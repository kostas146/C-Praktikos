﻿using System;

namespace Assignment_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter first number");
            string input = Console.ReadLine();
            double first = double.Parse(input);
            Console.WriteLine("Enter second number");
            string input1 = Console.ReadLine();
            double second = double.Parse(input1);
            Console.WriteLine("Enter third number");
            string input0 = Console.ReadLine();
            double third = double.Parse(input0);

            if ((third > second) && (third > first))
                Console.WriteLine("The third number is the Biggest value");
            if ((third < second) && (third < first))
                Console.WriteLine("The third number is the Lowest value");
            if ((third > first) || (third > second))
                Console.WriteLine("The third number is not the Lowest value");
          
        }
    }
}
