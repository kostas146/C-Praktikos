﻿using System;

namespace Assignment_8
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter number of working hours: ");
            string input = Console.ReadLine();
            int hours = int.Parse(input);
            Console.WriteLine("Enter number of years: ");
            string input0 = Console.ReadLine();
            int years = int.Parse(input0);
            Console.WriteLine("Enter number of failures: ");
            string input1 = Console.ReadLine();
            int fails = int.Parse(input1);

            if ((hours < 10000) && (years <= 7) && (fails < 25))
            { Console.WriteLine(" Machine doesn't need to be replaced"); }
            else
            { Console.Write("Machine needs to be replaced."); }
        }
    }
}
