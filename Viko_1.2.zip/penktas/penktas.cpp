﻿// penktas.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

int main()
{
    double sunaudota;
    double suma;
    std::cout << "iveskite sunaudota elektra: ";
    std::cin >> sunaudota;
    if (sunaudota <= 50)
    {
        suma = sunaudota * 0.5;
        suma += suma * 0.2;
        std::cout << "suma " << suma;
    }
    else if (sunaudota >= 50 && sunaudota <= 150)
    {
        sunaudota -= 50;
        suma = 50 * 0.5 + sunaudota * 0.75;
        suma += suma * 0.2;
        std::cout << "suma " << suma;
    }
    else if (sunaudota >= 151 && sunaudota <= 250)
    {
        sunaudota -= 150;
        suma = 50 * 0.5 + 100 * 0.75 + sunaudota * 1.2;
        suma += suma * 0.2;
        std::cout << "suma " << suma;
    }

    else if (sunaudota > 250)
    {
        sunaudota -= 250;
        suma = 50 * 0.5 + 100 * 0.75 + 100 * 1.2 + sunaudota * 1.5;
        suma += suma * 0.2;
        std::cout << "suma " << suma;
    }
}

//5.     Parašykite programą, kuri, įvedus sunaudotos elektros energijos kiekį, pateiktų sąskaitą salos gyventojams pagal tokius įkainius :

//Pirmi 50 kW kainuoja  0.5 eur / kW
//Viršijus 50 kW, kitiems 100 kW kaina 0.75 eur / kW.
//Dar sekančiam 100 kW taikomas tarifas 1.20 eur / kW
//Viršijus 250 kW, 1.50 eur / kW
//Taip pat taikomas 20 proc.administravimo mokesti