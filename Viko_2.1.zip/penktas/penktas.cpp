// penktas.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

int main()
{
    int liekana;
    int count = 0;

    for (int i = 1; count!= 43; i++)
    {
        int temp = i;
        liekana = temp % 10; //randam pirma skaitmeni
        temp = temp / 10; // dalinam , kad rastume pirma skaiciu


        if (liekana != 0 && i % liekana == 0) // jeigu nulis netinka/ jeigu skaicius dalinas is skaitmenio
        {
            liekana = temp % 10; // pirmas skaicius
            if (i < 10) // parasiau,nes kodas padalinus is 10 praranda galimybe pirminius skaicius gauti.
            {
                std::cout << i << " ";
                count++;
            }
            //if (liekana != 0 && i % liekana == 0) // jeigu ir pirmas skaitmuo dalinas, gaunasi viskas.
            //{
                std::cout << i << " ";
                count++;
            
        }
    }
}

//bool funkcija(int sk) {
//    int n = sk;
//    int liekana, atbula = 0;
//    while (sk > 0) {
//
//        liekana = sk % 10;
//        atbula = atbula * 10 + liekana;
//        sk /= 10;
//    }
//    return (n == atbula);
//}
